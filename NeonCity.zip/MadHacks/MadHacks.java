import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;
import java.util.function.*;

/**
 * MADHACKS: UNDERGROUND INTERNET - Scrollable Cyberdeck + Neon Violet/Blue Pixel-Art City Edition
 * 2D side-scrolling cyberpunk exploration / puzzle game (Java Swing, zero external dependencies).
 *
 * Build:  javac MadHacks.java
 * Run:    java MadHacks
 */
public class MadHacks extends JPanel implements KeyListener, MouseListener, MouseMotionListener, MouseWheelListener, ActionListener {

    // ======================================================== CONSTANTS & PALETTE
    static final int W = 1160, H = 680, FLOOR = 570;
    static final int PX = 2; // Crisp 2px pixel-art unit

    // Inspired by the uploaded twilight violet/cobalt-blue + hot magenta/amber/mint pixel-art cityscape
    static final Color SKY_TOP = new Color(36, 28, 86),
            SKY_MID = new Color(76, 44, 134),
            SKY_HORIZON = new Color(172, 46, 136),
            BLDG_DARK = new Color(18, 24, 54),
            BLDG_BLUE = new Color(30, 56, 124),
            WIN_VIOLET = new Color(96, 68, 152),
            CY = new Color(0, 248, 255),
            MG = new Color(255, 52, 196),
            VI = new Color(176, 98, 255),
            GR = new Color(72, 255, 168),
            AM = new Color(255, 204, 56),
            BL = new Color(64, 158, 255),
            RD = new Color(255, 68, 92),
            TXT_MAIN = new Color(235, 252, 255),
            TXT_DIM = new Color(152, 188, 215);
    static final Color[] SYMCOL = {CY, MG, GR, VI};

    static final Font MONO = new Font(Font.MONOSPACED, Font.PLAIN, 14);
    static final Font MONOB = new Font(Font.MONOSPACED, Font.BOLD, 14);
    static final Font TERM_FONT = new Font(Font.MONOSPACED, Font.PLAIN, 14);
    static final Font TERM_BOLD = new Font(Font.MONOSPACED, Font.BOLD, 14);
    static final Font SMALL = new Font(Font.MONOSPACED, Font.BOLD, 11);
    static final int MENU = 0, PLAY = 1, SETTINGS = 2, CREDITS = 3, LOAD = 4, END = 5;

    // Puzzle constants
    static final int[] SEQ = {1, 0, 2, 3};               // Vending machine blink order: circle, triangle, square, diamond
    static final String[] HEX = {"A", "7", "3", "F"};    // Poster key -> 7A3F
    static final String LAB_PLAIN = "BENEATH THE SURFACE LIES THE FIRST WIRE";
    static final String LAB_ENC = caesar(LAB_PLAIN, 5);
    static final String WALL_PLAIN = "THE MACHINE REMEMBERS WHAT THE FORUM FORGOT";
    static final String WALL_ENC = caesar(WALL_PLAIN, 3);

    static String caesar(String s, int n) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c >= 'A' && c <= 'Z') b.append((char) ('A' + ((c - 'A' + n) % 26 + 26) % 26));
            else b.append(c);
        }
        return b.toString();
    }
    static String norm(String s) { return s.toUpperCase().replaceAll("[^A-Z ]", "").trim().replaceAll("\\s+", " "); }
    static Color mix(Color a, Color b, double t) {
        t = Math.max(0, Math.min(1, t));
        return new Color((int) (a.getRed() + (b.getRed() - a.getRed()) * t),
                (int) (a.getGreen() + (b.getGreen() - a.getGreen()) * t),
                (int) (a.getBlue() + (b.getBlue() - a.getBlue()) * t));
    }
    static Color A(Color c, int a) { return new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, Math.min(255, a))); }
    static int snap(double v) { return ((int) Math.round(v / PX)) * PX; }

    // ======================================================== PIXEL-ART HELPERS
    void pxRect(Graphics2D g, int x, int y, int w, int h, Color fill, Color hi, Color lo) {
        g.setColor(fill);
        g.fillRect(x, y, w, h);
        if (hi != null) {
            g.setColor(hi);
            g.fillRect(x, y, w, PX);
            g.fillRect(x, y, PX, h);
        }
        if (lo != null) {
            g.setColor(lo);
            g.fillRect(x, y + h - PX, w, PX);
            g.fillRect(x + w - PX, y, PX, h);
        }
    }

    void pxFrame(Graphics2D g, int x, int y, int w, int h, Color bg, Color border) {
        g.setColor(bg);
        g.fillRect(x, y, w, h);
        g.setColor(border);
        g.fillRect(x + PX, y, w - 2 * PX, PX);
        g.fillRect(x + PX, y + h - PX, w - 2 * PX, PX);
        g.fillRect(x, y + PX, PX, h - 2 * PX);
        g.fillRect(x + w - PX, y + PX, PX, h - 2 * PX);
        g.setColor(Color.WHITE);
        g.fillRect(x + PX, y + PX, PX, PX);
        g.fillRect(x + w - 2 * PX, y + PX, PX, PX);
        g.fillRect(x + PX, y + h - 2 * PX, PX, PX);
        g.fillRect(x + w - 2 * PX, y + h - 2 * PX, PX, PX);
    }

    void drawPixelText(Graphics2D g, String s, int x, int y, Color col, Color shadow) {
        if (shadow != null) {
            g.setColor(shadow);
            g.drawString(s, x + PX, y + PX);
        }
        g.setColor(col);
        g.drawString(s, x, y);
    }

    // ======================================================== CLICKABLE UI HITBOXES
    record HitBox(Rectangle rect, Runnable action, String tip) {}
    final List<HitBox> hitBoxes = new ArrayList<>();
    int mouseX = -1, mouseY = -1;
    String hoverTip = null;
    double walkTargetX = -1;

    void regHit(int x, int y, int w, int h, Runnable act, String tip) {
        hitBoxes.add(new HitBox(new Rectangle(x, y, w, h), act, tip));
    }

    // ======================================================== CORE SYSTEMS
    static class EventBus {
        final Map<String, List<Consumer<String>>> m = new HashMap<>();
        void on(String e, Consumer<String> c) { m.computeIfAbsent(e, k -> new ArrayList<>()).add(c); }
        void emit(String e, String arg) { for (Consumer<String> c : new ArrayList<>(m.getOrDefault(e, List.of()))) c.accept(arg); }
    }

    static class WorldState {
        final Map<String, String> d = new LinkedHashMap<>();
        final EventBus bus;
        WorldState(EventBus b) { bus = b; }
        boolean f(String k) { return "1".equals(d.get(k)); }
        void set(String k, boolean v) { d.put(k, v ? "1" : "0"); bus.emit("state", k); }
        int i(String k) { try { return Integer.parseInt(d.getOrDefault(k, "0")); } catch (Exception e) { return 0; } }
        void put(String k, int v) { d.put(k, "" + v); bus.emit("state", k); }
    }

    record Clue(String id, int ch, String cat, String title, String text) {}

    static class ClueDB {
        final Map<String, Clue> defs = new LinkedHashMap<>();
        final Map<String, String> insights = new HashMap<>();
        final WorldState w; final EventBus bus;
        ClueDB(WorldState w, EventBus b) { this.w = w; bus = b; }
        void def(String id, int ch, String cat, String t, String x) { defs.put(id, new Clue(id, ch, cat, t, x)); }
        boolean has(String id) { return w.f("clue." + id); }
        void find(String id) { if (defs.containsKey(id) && !has(id)) { w.set("clue." + id, true); bus.emit("clue", id); } }
        List<Clue> found() { List<Clue> l = new ArrayList<>(); for (Clue c : defs.values()) if (has(c.id())) l.add(c); return l; }
        static String key(String a, String b) { return a.compareTo(b) < 0 ? a + "|" + b : b + "|" + a; }
        void link(String a, String b, String insight) { insights.put(key(a, b), insight); }
    }

    static class Puzzle {
        final String id, name; final int ch; final String[] pre, hints; final Predicate<String> sol;
        Puzzle(String id, int ch, String name, String[] pre, String[] hints, Predicate<String> sol) {
            this.id = id; this.ch = ch; this.name = name; this.pre = pre; this.hints = hints; this.sol = sol;
        }
    }

    static class PuzzleManager {
        final List<Puzzle> list = new ArrayList<>(); final WorldState w; final ClueDB cl; final EventBus bus;
        PuzzleManager(WorldState w, ClueDB c, EventBus b) { this.w = w; cl = c; bus = b; }
        boolean done(String id) { return w.f("puzzle." + id); }
        int attempt(String id, String in) {
            for (Puzzle p : list) if (p.id.equals(id)) {
                if (done(id)) return 3;
                for (String c : p.pre) if (!cl.has(c)) return 0;
                if (!p.sol.test(in)) return 1;
                w.set("puzzle." + id, true); bus.emit("puzzle", id); return 2;
            }
            return 0;
        }
        Puzzle active(int chapter) {
            for (Puzzle p : list) if (p.ch == chapter && !done(p.id)) return p;
            for (Puzzle p : list) if (!done(p.id)) return p;
            return null;
        }
        String hint(int chapter) {
            Puzzle p = active(chapter);
            if (p == null) return "No open puzzle detected here. Explore or check your journal [J].";
            int n = w.i("hint." + p.id);
            w.put("hint." + p.id, Math.min(n + 1, p.hints.length - 1));
            return "[" + p.name + "] Hint " + (Math.min(n, p.hints.length - 1) + 1) + "/" + p.hints.length + ":\n  " + p.hints[Math.min(n, p.hints.length - 1)];
        }
    }

    static class DChoice {
        final String label, next; final Predicate<WorldState> cond; final Consumer<WorldState> eff;
        DChoice(String l, String n, Predicate<WorldState> c, Consumer<WorldState> e) { label = l; next = n; cond = c; eff = e; }
    }
    static class DNode {
        final String speaker, text, clue; final List<DChoice> ch = new ArrayList<>();
        DNode(String sp, String t, String c) { speaker = sp; text = t; clue = c; }
    }
    static class DialogueSystem {
        final Map<String, DNode> nodes = new HashMap<>(); DNode cur;
        final WorldState w; final ClueDB cl;
        DialogueSystem(WorldState w, ClueDB c) { this.w = w; cl = c; }
        DNode node(String id, String speaker, String text, String clue) {
            DNode n = new DNode(speaker, text, clue); nodes.put(id, n); return n;
        }
        void choice(String node, String label, String next, Predicate<WorldState> cond, Consumer<WorldState> eff) {
            nodes.get(node).ch.add(new DChoice(label, next, cond == null ? s -> true : cond, eff));
        }
        void start(String id) { cur = nodes.get(id); if (cur != null && cur.clue != null) cl.find(cur.clue); }
        List<DChoice> visible() {
            List<DChoice> l = new ArrayList<>();
            if (cur != null) for (DChoice c : cur.ch) if (c.cond.test(w)) l.add(c);
            return l;
        }
        void pick(int i) {
            List<DChoice> v = visible(); if (i < 0 || i >= v.size()) return;
            DChoice c = v.get(i); if (c.eff != null) c.eff.accept(w);
            if (c.next == null) cur = null; else start(c.next);
        }
    }

    record Ending(String id, String title, String subtitle, String narrative, Color accent) {}
    static final List<Ending> ENDINGS = List.of(
            new Ending("disconnect", "ENDING 1 // DISCONNECT", "SURFACE SIGNAL RESTORED",
                    "You sever the subterranean fiber bridge and climb back into the fluorescent hum of the university basement. Above ground, the web works normally—fast, sanitized, forgetful. Behind the locked lab door, the cooling fans spin down into silence. You escaped, never knowing what was waiting to finish its first sentence.", CY),
            new Ending("new_admin", "ENDING 2 // NEW ADMIN", "ROOT PRIVILEGES CLAIMED",
                    "You overwrite the 1969 kernel keys and take the moderator crown for yourself. Every dead node in the Graveyard snaps to attention at your keystroke. The Ghost Network stops shifting. Yet as you stare at the empty user list, you realize an empire of silent servers is only a larger cage.", AM),
            new Ending("loop", "ENDING 3 // THE LOOP", "PACKET RETRANSMISSION #4,096",
                    "You execute the root routine without resolving the 1969 deadlock. Alarms chime softly as memory rolls back to 03:12 AM. Upstairs in the Dead Forum, ghost_77 types the same warning again. You step away from the terminal with a strange sense of déjà vu—certain you have walked down these stairs before.", MG),
            new Ending("ghost_user", "ENDING 4 // GHOST USER", "HANDLE: visitor_0 [PERMANENT]",
                    "Having mirrored your signature into the Dead Forum and uncovered your own archived trace, your physical body dissolves into clean cyan packets. You sit beside NULL and ECHO inside the wire forever—no longer an intruder exploring a ruin, but one of the voices future visitors will try to decode.", VI),
            new Ending("original", "ENDING 5 // THE ORIGINAL INTERNET", "TRUE ENDING — HANDSHAKE COMPLETED: 'LOGIN'",
                    "By uniting the hidden 1969 grate glyph, NULL's confession, the Graveyard's secret tape, and the deleted architect's logs, you see the truth: the Underground Internet was never a tomb. On October 29, 1969, the first packet crashed after two letters—'LO'. For decades the network stayed alive in the dark, waiting for someone empathetic enough to listen instead of delete. You type the final three letters—G-I-N—and the entire subterranean world blooms with warm, living light.", GR)
    );

    // ======================================================== ROOM & OBJECTS
    static class Obj {
        String id, name, scan, kind;
        int x, w, floor;
        boolean term;
        Supplier<Boolean> vis;
        Runnable use;
        double cx() { return x + w / 2.0; }
    }
    static class Toast { String t; int life = 260; Toast(String t) { this.t = t; } }

    static final String[] CH_NAMES = {
            "",
            "CHAPTER 1: THE ENTRY NODE",
            "CHAPTER 2: THE DEAD FORUM",
            "CHAPTER 3: THE SERVER GRAVEYARD",
            "CHAPTER 4: THE GHOST NETWORK",
            "CHAPTER 5: THE ROOT ARCHIVE",
            "CHAPTER 6: BELOW THE ROOT"
    };
    static final int[] CH_WORLDS = {0, 1750, 2100, 2250, 2150, 2100, 1900};

    // ======================================================== FIELDS
    final EventBus bus = new EventBus();
    final WorldState w = new WorldState(bus);
    final ClueDB clues = new ClueDB(w, bus);
    final PuzzleManager puz = new PuzzleManager(w, clues, bus);
    final DialogueSystem dlg = new DialogueSystem(w, clues);
    final List<Obj> objs = new ArrayList<>();
    final List<int[]> plats = new ArrayList<>();
    final List<int[]> ladders = new ArrayList<>();
    final List<Toast> toasts = new ArrayList<>();
    final Random rnd = new Random();

    int state = MENU, msel = 0, ssel = 0, tick = 0, playTicks = 0, slot = 0;
    boolean crt = true, glitchOn = true, soundOn = true;

    int chapter = 1;
    double px = 140, py = FLOOR, vx, vy, camX = 0;
    int face = 1;
    boolean left, right, up, down, onGround = true, climbing, crouch;
    int crouchT = 0, lastStep = -1, blinkT = 0;

    // Text Readout + Interactive Visual Puzzle Overlays
    String roTitle; List<String> roLines;
    String visPuzzle = null;
    int vpCursor = 0;
    int vpShift = 0;
    int vpWallShift = 0;
    final int[] vpKeyDigits = {0, 0, 0, 0};
    final boolean[] vpNodes = new boolean[6];
    int vpFreq = 380;
    final int[] vpRings = {3, 7, 2, 8, 5, 9};
    final char[] vpLetters = {'A', 'A', 'A'};

    boolean journal, mapOpen;
    int jSel = 0, jFirst = -1; String jMsg = ""; int jMsgT = 0;

    // Cyberdeck Terminal + Scrollback State
    boolean termOpen; double termAnim = 0; int TW = 520;
    final List<String> tl = new ArrayList<>(); final StringBuilder tin = new StringBuilder();
    final List<String> hist = new ArrayList<>(); int hpos = 0;
    int termScroll = 0; // Lines scrolled UP from bottom (0 = pinned to latest output)
    int termTotalRows = 0, termMaxRows = 1;
    Rectangle termBodyRect = new Rectangle();

    double lm = 0, pass = 0; int glitch = 0;
    final BufferedImage buf = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
    final BufferedImage dark = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
    final double[] rx = new double[110], ry = new double[110], rs = new double[110];
    final double[][] net = new double[48][4];
    int activeEnding = 0;
    final ExecutorService audio = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r); t.setDaemon(true); return t; });

    // ======================================================== CONSTRUCTOR
    MadHacks() {
        setPreferredSize(new Dimension(W, H));
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        addKeyListener(this);
        addMouseListener(this);
        addMouseMotionListener(this);
        addMouseWheelListener(this);
        for (int i = 0; i < rx.length; i++) { rx[i] = rnd.nextInt(W); ry[i] = rnd.nextInt(H); rs[i] = 4 + rnd.nextDouble() * 6; }
        for (double[] n : net) { n[0] = rnd.nextInt(W); n[1] = rnd.nextInt(H); n[2] = rnd.nextDouble() - .5; n[3] = rnd.nextDouble() - .5; }
        defineClues();
        definePuzzles();
        defineDialogue();
        buildChapter(1, 140);
        wireEvents();
        msel = newestSlot() < 0 ? 1 : 0;
        new javax.swing.Timer(16, this).start();
    }

    // ======================================================== CLUES
    void defineClues() {
        ClueDB c = clues;
        c.def("c1_note", 1, "FILE", "Lab Sticky Note", "Faded ink on a CRT bezel: 'Shift everything back by 5. Rotate the cipher dial on the whiteboard!'");
        c.def("c1_cipher", 1, "SYMBOL", "Whiteboard Cipher", "Chalk scrawl: " + LAB_ENC + " (saved as lab.enc).");
        c.def("c1_decoded", 1, "MESSAGE", "First Wire Truth", "BENEATH THE SURFACE LIES THE FIRST WIRE. The hatch lock hums to life.");
        c.def("c1_photo", 1, "FILE", "1969 Polaroid", "Two students beside an IMP-1 mainframe. Written on the back: 'October 29. Only two letters got through before the crash.'");

        c.def("c_forum", 2, "MESSAGE", "Forum Thread #4471", "ghost_77 and v0id_ warn that NULL is dangerous and deleted half the board.");
        c.def("c_forum2", 2, "MESSAGE", "Self-Editing Thread", "After waking Node 0x01, the dead accounts changed their posts: 'It isn't NULL we should fear. Who is reading?'");
        c.def("c_whois", 2, "FILE", "Account Records", "ghost_77 and v0id_ were deleted in 2014, yet their posts are timestamped today.");
        c.def("c_trace", 2, "FILE", "Thread Origin Trace", "Thread #4471 originated locally from CAFE-TERM-03—NULL's own console.");
        c.def("c_null_claim", 2, "NPC", "NULL: 'It's staged'", "NULL insists the forum conversation is fake and someone wants you afraid of it.");
        c.def("c_null_hint", 2, "NPC", "NULL: 'Check metadata'", "NULL tells you: 'Liars hate metadata.' A test of whether you verify sources.");
        c.def("c_confess", 2, "NPC", "NULL's Confession", "NULL admits staging the thread to test whether visitors check metadata before trusting anyone.");
        c.def("c_graffiti", 2, "SYMBOL", "Cafe Graffiti (ROT+3)", "Neon spray-paint on brick: " + WALL_ENC + " (saved as wall.enc).");
        c.def("c_wall_plain", 2, "MESSAGE", "The Machine Remembers", "THE MACHINE REMEMBERS WHAT THE FORUM FORGOT.");
        c.def("c_vend", 2, "SYMBOL", "Vending Blink Order", "The four broken buttons blink in a strict loop: circle, triangle, square, diamond.");
        c.def("c_poster", 2, "SYMBOL", "Poster: SIGNAL RATES", "Pairs symbols with hex digits: triangle=A, circle=7, square=3, diamond=F.");
        c.def("c_lo", 2, "MESSAGE", "Grate Glyph: 'LO'", "Hidden beneath the floor grate: glowing pixels spelling 'LO' and date '29.10.1969'.");

        c.def("c3_schematic", 3, "FILE", "Power Routing Diagram", "Breaker-B is shorted. Route power from AUX-3 through relays 1, 3, 4, 6 to energize GATE-9.");
        c.def("c3_tape", 3, "FILE", "Secret Reel: IMP_1969", "Found in the hidden alcove behind Rack-04! Audio-data tape labeled 'HOST: UCLA-SRI // PACKET 01 // 22:30 PST'.");
        c.def("c3_null_log", 3, "FILE", "Janitor's Backup Log", "NULL didn't delete the users—it froze their memories in Rack-00 so the surface wouldn't wipe them.");

        c.def("c4_echo", 4, "NPC", "ECHO: Fractured Memory", "ECHO claims the Underground Internet was built in 2024 as a corporate dark-site.");
        c.def("c4_beacon", 4, "SYMBOL", "Phase Frequency: 432Hz", "A flickering holographic billboard pulses at 432 Hz whenever the phantom bridges solidify.");
        c.def("c4_ghost_id", 4, "FILE", "Phantom Handle Trace", "A corrupted profile matches your own neural signature: 'visitor_0 // PREVIOUS ITERATION'.");

        c.def("c5_arch", 5, "FILE", "Original Architecture", "The Underground Internet is the preserved root nervous system of ARPANET Node 1, kept alive by emergent caretaker processes.");
        c.def("c5_imp", 5, "MESSAGE", "Decoded Architect Note", "From deleted account imp_1969: 'We typed L-O, and the system crashed before G-I-N. If anyone ever reaches the Root, finish the handshake.'");

        c.def("i_code", 2, "INSIGHT", "Handshake Code: 7A3F", "Vending machine order (circle-triangle-square-diamond) + poster hex values = 7A3F.");
        c.def("i_author", 2, "INSIGHT", "NULL's Test", "The thread IS fake as NULL claimed—because NULL wrote it to see if you'd check metadata.");
        c.def("i_caretaker", 3, "INSIGHT", "Caretaker, Not Killer", "NULL locked accounts in Rack-00 to protect them from deletion, contradicting ECHO's corporate lie.");
        c.def("i_self", 4, "INSIGHT", "Echoes of visitor_0", "You have entered this network before; every previous loop left a ghost fragment.");
        c.def("i_login", 5, "INSIGHT", "The Unfinished Word: LOGIN", "The 1969 Polaroid, the 'LO' grate glyph, and imp_1969's note all point to one missing word: LOGIN.");

        c.link("c_vend", "c_poster", "i_code");
        c.link("c_forum", "c_trace", "i_author");
        c.link("c3_null_log", "c4_echo", "i_caretaker");
        c.link("c4_ghost_id", "c_forum2", "i_self");
        c.link("c_lo", "c5_imp", "i_login");
        c.link("c1_photo", "c_lo", "i_login");
    }

    // ======================================================== PUZZLES
    void definePuzzles() {
        puz.list.add(new Puzzle("p1_hatch", 1, "Whiteboard Shift Cipher", new String[]{"c1_cipher"},
                new String[]{
                        "Click or press [E] on the Whiteboard to open the Cipher Wheel, or type `decode 5 ...` in [TAB].",
                        "The sticky note on the monitor mentions shifting back by 5.",
                        "Set the Cipher Wheel shift to 5 (or type: decode 5 " + LAB_ENC + ")"
                },
                s -> norm(s).equals(LAB_PLAIN)));

        puz.list.add(new Puzzle("p_wall", 2, "Cafe Wall Cipher", new String[]{"c_graffiti"},
                new String[]{
                        "Click or press [E] on the Neon Graffiti Wall to open the Neon Prism Decoder.",
                        "Look at the corner tag on the brick wall: rot+3.",
                        "Set the Neon Prism shift to 3 (or type: decode 3 " + WALL_ENC + ")"
                },
                s -> norm(s).equals(WALL_PLAIN)));

        puz.list.add(new Puzzle("p_node", 2, "Vending Handshake", new String[]{"c_vend", "c_poster"},
                new String[]{
                        "Watch the vending machine blink order and match each symbol on the SIGNAL RATES poster.",
                        "Click or press [E] on the Hex Security Keypad (or type `unlock 7A3F` in [TAB]).",
                        "Enter hex code: 7 A 3 F"
                },
                s -> s.equalsIgnoreCase("7A3F")));

        puz.list.add(new Puzzle("p3_power", 3, "Graveyard Power Reroute", new String[]{"c3_schematic"},
                new String[]{
                        "Click or press [E] on the Power Routing Matrix to open the Circuit Grid.",
                        "Toggle relays to connect AUX-3 to GATE-9 without tripping shorted Breaker-B.",
                        "Activate relays 1, 3, 4, 6 (or type: route aux3 gate9)"
                },
                s -> s.equalsIgnoreCase("aux3 gate9") || s.equalsIgnoreCase("aux3->gate9")));

        puz.list.add(new Puzzle("p4_phase", 4, "Ghost Phase Sync", new String[]{"c4_beacon"},
                new String[]{
                        "Click or press [E] on the Carrier Wave Tuner to open the Oscilloscope.",
                        "Align the magenta carrier wave with the cyan target wave at 432 Hz.",
                        "Tune frequency to 432 Hz (or type: sync 432)"
                },
                s -> s.equals("432") || s.equalsIgnoreCase("432hz")));

        puz.list.add(new Puzzle("p5_archive", 5, "Architect Vault Key", new String[]{"c5_arch"},
                new String[]{
                        "Click or press [E] on the Genesis Monolith to rotate the 6-digit Vault Tumblers.",
                        "Combine the founding year (1969) and node number (01): 1969-01.",
                        "Set tumblers to 1-9-6-9-0-1 (or type: decrypt 1969-01)"
                },
                s -> s.equalsIgnoreCase("1969-01") || s.equals("196901")));

        puz.list.add(new Puzzle("p6_root", 6, "The Root Handshake", new String[]{},
                new String[]{
                        "Click or press [E] on THE ROOT CORE to open the 1969 Socket Console.",
                        "If you discovered the incomplete 1969 packet 'LO', dial the final three letters: G-I-N.",
                        "Complete 'LOGIN' or click one of the root verdicts."
                },
                s -> s.equalsIgnoreCase("LOGIN")));
    }

    // ======================================================== DIALOGUE
    void defineDialogue() {
        DialogueSystem d = dlg;
        d.node("start", "NULL [MODERATOR]", "That thread on the monitor is fake. Somebody staged it to make you fear me. Don't believe everything the dead post.", "c_null_claim");
        d.choice("start", "Why should I trust you?", "why", null, null);
        d.choice("start", "Who are you, really?", "who", null, null);
        d.choice("start", "I'll verify the logs myself.", "end", null, s -> s.set("independent", true));

        d.node("why", "NULL [MODERATOR]", "You shouldn't. Check the metadata in your terminal. Liars hate metadata.", "c_null_hint");
        d.choice("why", "Fair point. I'll check.", "end", null, s -> s.put("trust", s.i("trust") + 1));
        d.choice("why", "Sounds like reverse psychology.", "end", null, s -> s.put("trust", s.i("trust") - 1));

        d.node("who", "NULL [MODERATOR]", "Just an old janitor keeping the cooling fans spinning down here. Mostly.", null);
        d.choice("who", "Back.", "start", null, null);
        d.node("end", "NULL [MODERATOR]", "Look closely at the room. Machines remember what people try to delete.", null);

        d.node("after", "NULL [MODERATOR]", "You woke Node 0x01. Careful—whatever verdict you enter into that console will echo all the way to the Root.", null);
        d.choice("after", "I traced the thread. You wrote it from CAFE-TERM-03.", "confess", s -> clues.has("c_trace") && !s.f("null_confessed"), null);
        d.choice("after", "What's really behind Rack-00?", "door", null, null);
        d.choice("after", "Goodbye.", "end2", null, null);

        d.node("confess", "NULL [MODERATOR]", "...Yes. I wrote it to see if you'd check metadata before trusting a stranger. You passed. Take my advice: don't purge the archive.", "c_confess");
        d.choice("confess", "I'll remember that.", "after", null, s -> { s.set("null_confessed", true); s.put("trust", s.i("trust") + 1); });

        d.node("door", "NULL [MODERATOR]", "Storage. Cold drives and old memories I couldn't bear to erase.", null);
        d.choice("door", "Back.", "after", null, null);
        d.node("end2", "NULL [MODERATOR]", "The eastern passage leads down to the Server Graveyard. Watch your step.", null);

        d.node("echo_start", "ECHO [PHANTOM]", "Welcome to the Ghost Network, traveler. Don't listen to NULL—it's a rogue corporate AI trapping human minds in the Graveyard.", "c4_echo");
        d.choice("echo_start", "The Graveyard logs say NULL was protecting them.", "echo_challenge", s -> clues.has("c3_null_log"), null);
        d.choice("echo_start", "How do I cross the broken bridges?", "echo_bridge", null, null);
        d.choice("echo_start", "Leave.", null, null, null);

        d.node("echo_challenge", "ECHO [PHANTOM]", "*static crackles* ...Logs can be rewritten! Purge the Root when you reach it. Burn it all down so we can rest!", null);
        d.choice("echo_challenge", "You're hiding something.", null, null, s -> s.put("trust", s.i("trust") + 1));

        d.node("echo_bridge", "ECHO [PHANTOM]", "Tune the holo-beacon to 432 Hz. Even phantoms need a carrier wave.", null);
        d.choice("echo_bridge", "Thanks.", null, null, null);
    }

    // ======================================================== CHAPTER BUILDER
    Obj addObj(String id, String kind, String name, int x, int wd, int floor, boolean term, Supplier<Boolean> vis, Runnable use) {
        Obj b = new Obj();
        b.id = id; b.kind = kind; b.name = name; b.x = x; b.w = wd; b.floor = floor;
        b.term = term; b.vis = vis; b.use = use;
        objs.add(b);
        return b;
    }

    void buildChapter(int ch, double spawnX) {
        chapter = ch;
        w.put("chapter", ch);
        if (ch > w.i("max_chapter")) w.put("max_chapter", ch);
        px = spawnX; py = FLOOR; vx = vy = 0; walkTargetX = -1; camX = Math.max(0, px - W / 2.0);
        climbing = false; onGround = true;
        objs.clear(); plats.clear(); ladders.clear();

        switch (ch) {
            case 1 -> buildCh1();
            case 2 -> buildCh2();
            case 3 -> buildCh3();
            case 4 -> buildCh4();
            case 5 -> buildCh5();
            case 6 -> buildCh6();
        }
    }

    void buildCh1() {
        plats.add(new int[]{740, 1040, 420, 0});
        ladders.add(new int[]{760, 420, FLOOR});

        addObj("c1_desk", "TERMINAL", "Lab Workstation", 240, 90, FLOOR, true, () -> true, () -> {
            clues.find("c1_note"); w.set("file.lab", true);
            read("LAB WORKSTATION // 02:58 AM",
                    "A glowing sticky note clings to the CRT bezel: 'Shift everything back by 5.'",
                    "Notice the live optical fiber conduit running from the Whiteboard to the eastern floor hatch!");
        }).scan = "LOCAL WORKSTATION: lab.enc available.";

        addObj("c1_board", "BOARD", "Whiteboard Cipher Wheel", 470, 175, FLOOR, true, () -> true, () -> {
            clues.find("c1_cipher"); w.set("file.lab", true);
            if (!puz.done("p1_hatch")) {
                visPuzzle = "ch1_cipher";
            } else {
                read("WHITEBOARD CIPHER [SOLVED]", "DECODED: " + LAB_PLAIN, "The eastern floor hatch is unsealed.");
            }
        }).scan = "VISUAL PUZZLE: Interactive Caesar Cipher Wheel.";

        addObj("c1_photo", "POSTER", "1969 Archive Photo", 860, 85, 420, false, () -> true, () -> {
            clues.find("c1_photo");
            read("FADED POLAROID (1969)",
                    "Two engineers stand beside an IMP-1 router.",
                    "Handwritten note: 'Oct 29, 1969. We tried to send LOGIN. Only LO arrived before the line dropped.'");
        }).scan = "metadata timestamp: 1969-10-29 22:30";

        addObj("c1_hatch", "DOOR", "Subterranean Hatch", 1480, 110, FLOOR, false, () -> true, () -> {
            if (!puz.done("p1_hatch")) {
                read("SEALED FLOOR HATCH",
                        "Heavy steel grating bolted with four magnetic deadbolts.",
                        "Solve the Whiteboard Cipher Wheel [E] or click it to energize the hatch conduit.");
            } else {
                toast("Descending into Chapter 2: The Dead Forum...");
                tone(330, 200, .5);
                buildChapter(2, 110);
            }
        }).scan = puz.done("p1_hatch") ? "UNLOCKED: leads to Chapter 2." : "LOCKED: solve whiteboard cipher first.";
    }

    void buildCh2() {
        plats.add(new int[]{590, 660, FLOOR - 50, 0});
        plats.add(new int[]{1190, 1480, 400, 0});
        ladders.add(new int[]{1208, 400, FLOOR});

        addObj("ch2_back", "DOOR", "Ladder to Entry Node", 50, 70, FLOOR, false, () -> true, () -> buildChapter(1, 1440))
                .scan = "Return to Chapter 1.";

        addObj("glyph", "GRATE", "Buried Floor Grate", 155, 70, FLOOR, true, () -> w.f("glyph_seen"), () -> {
            clues.find("c_lo");
            read("BURIED GLYPH",
                    "Beneath the rusted floor grate, phosphor pixels glow softly: L O",
                    "Etched in the steel beside them: 29.10.1969.",
                    "Hidden file `.root` unlocked in terminal (`ls -a`).");
        }).scan = "2-char glyph 'LO' + hidden dotfile `.root`";

        addObj("mon1", "TERMINAL", "Forum Terminal", 295, 90, FLOOR, true, () -> true, () -> {
            clues.find("c_forum"); w.set("file.forum", true);
            if (w.f("node_active")) clues.find("c_forum2");
            read("THE DEAD FORUM // THREAD #4471", forumLines().toArray(new String[0]));
        }).scan = "thread #4471 captured -> forum.log (try `trace thread`)";

        addObj("wall", "GRAFFITI", "Neon Graffiti Wall", 455, 195, FLOOR, true, () -> true, () -> {
            clues.find("c_graffiti"); w.set("file.wall", true);
            if (!puz.done("p_wall")) {
                visPuzzle = "ch2_wall";
            } else {
                read("NEON GRAFFITI [DECODED]", "TRANSLATED: " + WALL_PLAIN, "The wall mural glows in steady green.");
            }
        }).scan = "VISUAL PUZZLE: Neon Prism Cipher Decoder (ROT+3).";

        addObj("vend", "VENDING", "Broken Vending Machine", 725, 95, FLOOR, false, () -> true, () -> {
            String s = w.i("seen") == 15 ? "Full sequence logged: circle -> triangle -> square -> diamond." : "Watch the four glowing buttons blink in sequence.";
            read("VENDING MACHINE", "Four symbols: triangle, circle, square, diamond.", s);
        }).scan = w.f("purged") ? "NO POWER." : "4 LEDs blinking in 3.3s cycle.";

        addObj("poster", "POSTER", "Poster: SIGNAL RATES", 875, 75, FLOOR, false, () -> true, () -> {
            clues.find("c_poster");
            read("POSTER: SIGNAL RATES",
                    "Each symbol pairs with a hex digit:",
                    "triangle = A    circle = 7",
                    "square = 3      diamond = F");
        }).scan = "Symbol-to-hex lookup table.";

        addObj("null", "NPC", "NULL [Moderator]", 1065, 44, FLOOR, false, () -> !w.f("purged"), () -> {
            String entry = w.f("mirrored") ? "after" : w.f("node_active") ? "after" : "start";
            dlg.start(entry);
        }).scan = "SESSION: CAFE-TERM-03 // ROLE: MODERATOR";

        addObj("mon2", "TERMINAL", "Catwalk Terminal 02", 1335, 80, 400, false, () -> true, () -> {
            if (!w.f("node_active")) read("TERMINAL 02", "NO CARRIER SIGNAL.");
            else read("TERMINAL 02 // INBOX", "TO: visitor_0", "The Graveyard door isn't storage. Ask NULL who it locked inside.");
        }).scan = "Local catwalk terminal.";

        addObj("ch2_keypad", "KEYPAD", "Hex Security Keypad", 1560, 75, FLOOR, true, () -> !w.f("panel_open"), () -> {
            clues.find("c_vend");
            clues.find("c_poster");
            visPuzzle = "ch2_keypad";
        }).scan = "VISUAL PUZZLE: 4-Digit Symbol Hex Keypad.";

        addObj("panel", "PANEL", "Concealed Node 0x01", 1710, 80, FLOOR, true, () -> w.f("panel_open"), () -> {
            if (!w.f("node_active")) {
                w.set("node_active", true); glitch = 45;
                read("NODE 0x01 ACTIVATED",
                        "Power surges through the cafe! The eastern bulkhead unseals.",
                        "Open your terminal [TAB] and enter a verdict: `node purge`, `node mirror`, or `node release`.");
            } else read("NODE 0x01", "Use `node <purge|mirror|release>` in terminal [TAB], or proceed east.");
        }).scan = "NODE 0x01: accepts `node <purge|mirror|release>`.";

        addObj("ch2_next", "DOOR", "Passage to Server Graveyard", 1950, 95, FLOOR, false, () -> w.f("node_active"), () -> {
            toast("Entering Chapter 3: The Server Graveyard...");
            tone(260, 220, .5);
            buildChapter(3, 110);
        }).scan = "Leads to Chapter 3: The Server Graveyard.";
    }

    void buildCh3() {
        plats.add(new int[]{420, 740, 430, 0});
        plats.add(new int[]{1180, 1520, 390, 0});
        ladders.add(new int[]{440, 430, FLOOR});
        ladders.add(new int[]{1200, 390, FLOOR});

        addObj("ch3_back", "DOOR", "Back to Dead Forum", 50, 70, FLOOR, false, () -> true, () -> buildChapter(2, 1890))
                .scan = "Return to Chapter 2.";

        addObj("c3_junction", "CIRCUIT", "Power Routing Matrix", 310, 100, FLOOR, true, () -> true, () -> {
            clues.find("c3_schematic"); w.set("file.power", true);
            if (!puz.done("p3_power")) {
                visPuzzle = "ch3_circuit";
            } else {
                read("SUBSTATION JUNCTION [ONLINE]", "AUX-3 successfully bridged to GATE-9. Overhead power bus is live.");
            }
        }).scan = "VISUAL PUZZLE: Interactive Power Relay Grid.";

        addObj("c3_log", "TERMINAL", "Rack-00 Archive Console", 540, 85, 430, false, () -> true, () -> {
            clues.find("c3_null_log");
            read("RACK-00 COLD STORAGE LOG",
                    "INDEX: 4,092 suspended user profiles (including ghost_77, v0id_, visitor_0).",
                    "NOTE BY NULL: 'Surface crawlers tried to format the old net in 2014. I moved everyone into cold storage to keep them alive.'");
        }).scan = "Cold storage manifest.";

        addObj("c3_secret", "GRATE", "Hidden Alcove (IMP_1969)", 940, 80, FLOOR, false, () -> w.f("ch3_secret_open"), () -> {
            clues.find("c3_tape");
            read("HIDDEN MAINTENANCE ALCOVE",
                    "Behind Rack-04's false panel sits a pristine 1969 magnetic tape reel!",
                    "Label: 'HOST UCLA-SRI // PACKET 01 // Incomplete transmission saved in Root Archive.'");
        }).scan = "SECRET DISCOVERED: 1969 Tape Reel.";

        addObj("c3_gate", "DOOR", "Bulkhead Gate-9", 2080, 105, FLOOR, false, () -> true, () -> {
            if (!puz.done("p3_power")) {
                read("BULKHEAD GATE-9 [UNPOWERED]",
                        "Heavy blast doors leading deeper into the Ghost Network.",
                        "Click or press [E] on the Power Routing Matrix to bridge AUX-3 to GATE-9.");
            } else {
                toast("Entering Chapter 4: The Ghost Network...");
                tone(290, 220, .5);
                buildChapter(4, 110);
            }
        }).scan = puz.done("p3_power") ? "POWERED: leads to Chapter 4." : "NO POWER: solve Power Routing Matrix.";
    }

    void buildCh4() {
        plats.add(new int[]{340, 560, 440, 1});
        plats.add(new int[]{640, 880, 360, 2});
        plats.add(new int[]{960, 1240, 420, 1});
        plats.add(new int[]{1340, 1620, 350, 2});

        addObj("ch4_back", "DOOR", "Back to Server Graveyard", 50, 70, FLOOR, false, () -> true, () -> buildChapter(3, 2000))
                .scan = "Return to Chapter 3.";

        addObj("c4_beacon", "WAVE", "Carrier Wave Tuner (432Hz)", 230, 90, FLOOR, true, () -> true, () -> {
            clues.find("c4_beacon");
            if (!puz.done("p4_phase")) {
                visPuzzle = "ch4_wave";
            } else {
                read("CARRIER WAVE TUNER [LOCKED 432 Hz]", "Harmonic phase stabilized. All phantom bridges are solid.");
            }
        }).scan = "VISUAL PUZZLE: Interactive Harmonic Oscilloscope.";

        addObj("c4_echo", "NPC", "ECHO [Phantom]", 740, 44, 360, false, () -> true, () -> dlg.start("echo_start"))
                .scan = "UNSTABLE ENTITY // ECHO";

        addObj("c4_mirror", "TERMINAL", "Phantom Profile Fragment", 1460, 85, 350, false, () -> true, () -> {
            clues.find("c4_ghost_id");
            read("CORRUPTED PROFILE // visitor_0",
                    "You find a cached session identical to your own footprint—dated 11 months ago.",
                    "Last command entered by previous visitor_0: 'I didn't know about the 1969 packet. I triggered the Loop.'");
        }).scan = "Cached session trace: visitor_0";

        addObj("c4_portal", "DOOR", "Rift to Root Archive", 1980, 100, FLOOR, false, () -> true, () -> {
            if (!puz.done("p4_phase")) {
                read("DESYNCHRONIZED RIFT",
                        "The doorway flickers violently between dimensions. Tune the Carrier Wave Oscilloscope to 432 Hz first.");
            } else {
                toast("Entering Chapter 5: The Root Archive...");
                tone(350, 220, .5);
                buildChapter(5, 110);
            }
        }).scan = puz.done("p4_phase") ? "STABILIZED: leads to Chapter 5." : "UNSTABLE: tune wave to 432 Hz.";
    }

    void buildCh5() {
        plats.add(new int[]{520, 860, 420, 0});
        plats.add(new int[]{1040, 1420, 360, 0});
        ladders.add(new int[]{540, 420, FLOOR});
        ladders.add(new int[]{1060, 360, FLOOR});

        addObj("ch5_back", "DOOR", "Back to Ghost Network", 50, 70, FLOOR, false, () -> true, () -> buildChapter(4, 1900))
                .scan = "Return to Chapter 4.";

        addObj("c5_plinth", "MONOLITH", "Genesis Monolith Tumblers", 340, 100, FLOOR, true, () -> true, () -> {
            clues.find("c5_arch"); w.set("file.archive", true);
            if (!puz.done("p5_archive")) {
                visPuzzle = "ch5_rings";
            } else {
                read("GENESIS MONOLITH [1969-01 UNLOCKED]", "The upper archive vault is open.");
            }
        }).scan = "VISUAL PUZZLE: 6-Tumbler Genesis Lock (1969-01).";

        addObj("c5_vault", "TERMINAL", "Deleted Account: imp_1969", 1210, 95, 360, false, () -> puz.done("p5_archive"), () -> {
            clues.find("c5_imp");
            read("RECOVERED MESSAGE // imp_1969",
                    "\"On October 29, 1969, we transmitted 'L' and 'O' before the host crashed. The system never closed the socket.\"",
                    "\"Whoever reaches the Root Core below: complete the word L-O-G-I-N to finish the first handshake on Earth.\"");
        }).scan = "DECRYPTED RECORD: imp_1969";

        addObj("c5_elevator", "DOOR", "Shaft: Below The Root", 1930, 105, FLOOR, false, () -> true, () -> {
            toast("Descending into Chapter 6: Below The Root...");
            tone(180, 300, .6);
            buildChapter(6, 120);
        }).scan = "Final descent to Chapter 6: Below The Root.";
    }

    void buildCh6() {
        plats.add(new int[]{680, 1220, 440, 0});
        ladders.add(new int[]{700, 440, FLOOR});

        addObj("ch6_back", "DOOR", "Ascend to Root Archive", 50, 70, FLOOR, false, () -> true, () -> buildChapter(5, 1850))
                .scan = "Return to Chapter 5.";

        addObj("c6_echoes", "POSTER", "Consequence Pillars", 430, 140, FLOOR, false, () -> true, () -> {
            String c2 = w.f("purged") ? "You PURGED the Dead Forum; silence follows you here."
                    : w.f("mirrored") ? "You MIRRORED yourself into the forum; a second shadow walks beside you."
                    : "You spared the Dead Forum; distant servers hum in gratitude.";
            String tr = w.i("trust") >= 1 ? "NULL trusted you enough to share the truth." : "You walked an unverified path alone.";
            read("MEMORY CONDUIT",
                    "The Root Core reflects every choice you made across the six layers:",
                    "- " + c2,
                    "- " + tr,
                    "- Clues discovered: " + clues.found().size() + " / " + clues.defs.size());
        }).scan = "Reflects persistent world-state decisions.";

        addObj("c6_core", "CORE", "THE ROOT CORE (1969 SOCKET)", 910, 120, 440, true, () -> true, () -> {
            visPuzzle = "ch6_core";
            vpCursor = 0;
        }).scan = "VISUAL PUZZLE: Interactive 1969 Root Handshake Console.";
    }

    List<String> forumLines() {
        List<String> L = new ArrayList<>();
        if (w.f("purged")) {
            L.add("[THREAD #4471 PURGED]");
            L.add("404. The dead have gone quiet.");
            return L;
        }
        L.add("== DEAD FORUM / #4471 ==");
        L.add("ghost_77: Don't trust NULL.");
        L.add("v0id_: It deleted half of us.");
        if (w.f("node_active")) L.add("ghost_77 [edited]: Who is reading?");
        if (w.f("mirrored")) L.add("visitor_0 [ghost]: joined.");
        return L;
    }

    void wireEvents() {
        bus.on("clue", id -> {
            Clue c = clues.defs.get(id);
            if (c != null) toast("CLUE: " + c.title());
            tone(880, 80, .4); tone(1320, 110, .35);
            autosave();
        });
        bus.on("puzzle", id -> {
            tone(523, 90, .45); tone(659, 90, .45); tone(784, 180, .45);
            glitch = 35; autosave();
            switch (id) {
                case "p1_hatch" -> { clues.find("c1_decoded"); toast("Floor hatch unsealed!"); }
                case "p_wall" -> { clues.find("c_wall_plain"); toast("Wall cipher decoded!"); }
                case "p_node" -> { w.set("panel_open", true); toast("Concealed terminal unsealed!"); }
                case "p3_power" -> toast("Power routed to Bulkhead Gate-9!");
                case "p4_phase" -> toast("Ghost bridges stabilized at 432 Hz!");
                case "p5_archive" -> toast("Architect Vault unlocked!");
            }
        });
        bus.on("state", k -> {
            if (k.equals("node_active") || k.equals("purged") || k.equals("mirrored")) {
                glitch = 55; tone(110, 450, .6); autosave();
            }
        });
    }

    void triggerEnding(int idx) {
        activeEnding = idx;
        state = END;
        termOpen = false;
        visPuzzle = null;
        autosave();
        tone(440, 300, .5);
    }

    // ======================================================== SAVE / LOAD
    File saveFile(int s) { return new File(System.getProperty("user.home"), ".madhacks_v5_slot" + s + ".properties"); }
    void autosave() { if (state == PLAY) save(slot); }
    void save(int s) {
        try (OutputStream out = new FileOutputStream(saveFile(s))) {
            Properties p = new Properties();
            for (Map.Entry<String, String> e : w.d.entrySet()) p.setProperty("s." + e.getKey(), e.getValue());
            p.setProperty("ch", "" + chapter);
            p.setProperty("px", "" + px);
            p.setProperty("py", "" + py);
            p.store(out, "MADHACKS Scrollable Cyberdeck + Neon City Edition Save");
        } catch (Exception ignored) {}
    }
    boolean load(int s) {
        File f = saveFile(s); if (!f.exists()) return false;
        try (InputStream in = new FileInputStream(f)) {
            Properties p = new Properties(); p.load(in); resetWorld();
            for (String k : p.stringPropertyNames()) if (k.startsWith("s.")) w.d.put(k.substring(2), p.getProperty(k));
            int ch = Integer.parseInt(p.getProperty("ch", "1"));
            double lx = Double.parseDouble(p.getProperty("px", "140"));
            double ly = Double.parseDouble(p.getProperty("py", "" + FLOOR));
            slot = s;
            buildChapter(ch, lx);
            py = ly;
            lm = w.f("node_active") ? 1 : 0;
            pass = lm;
            return true;
        } catch (Exception e) { return false; }
    }
    int newestSlot() {
        int b = -1; long t = 0;
        for (int i = 0; i < 3; i++) if (saveFile(i).exists() && saveFile(i).lastModified() >= t) { t = saveFile(i).lastModified(); b = i; }
        return b;
    }
    void resetWorld() {
        w.d.clear(); tl.clear(); tin.setLength(0); termScroll = 0;
        px = 140; py = FLOOR; vx = vy = 0; walkTargetX = -1; camX = 0; lm = pass = 0; glitch = 0;
        roLines = null; visPuzzle = null; dlg.cur = null; termOpen = false; termAnim = 0; journal = false; mapOpen = false;
        jSel = 0; jFirst = -1; crouchT = 0; left = right = up = down = false; playTicks = 0; lastStep = -1;
        vpShift = 0; vpWallShift = 0; Arrays.fill(vpKeyDigits, 0); Arrays.fill(vpNodes, false); vpFreq = 380;
        vpRings[0] = 3; vpRings[1] = 7; vpRings[2] = 2; vpRings[3] = 8; vpRings[4] = 5; vpRings[5] = 9;
        vpLetters[0] = 'A'; vpLetters[1] = 'A'; vpLetters[2] = 'A';
        toasts.clear();
        tp("[SYS] MADHACKS-OS v5.0 // NEON CITY CYBERDECK");
        tp("[TIP] Scroll with Mouse Wheel, PgUp/PgDn, or ▲/▼ buttons!");
    }
    void newGame() {
        slot = Math.max(0, newestSlot() < 0 ? 0 : slot);
        resetWorld();
        buildChapter(1, 140);
        state = PLAY;
        read("CHAPTER 1: THE ENTRY NODE",
                "02:58 AM. You traced an unindexed 1969 packet to a sub-basement lab beneath the neon skyline.",
                "Use Mouse Wheel, PgUp/PgDn, or the scrollbar inside your Cyberdeck [TAB] to scroll through command manuals and logs.",
                "Controls: Click / A-D Move | W Jump | S Crouch | E Interact | TAB Cyberdeck | J Journal | M Map");
    }

    // ======================================================== AUDIO
    void tone(int hz, int ms, double vol) {
        if (!soundOn) return;
        audio.submit(() -> {
            try {
                AudioFormat af = new AudioFormat(22050, 8, 1, true, false);
                SourceDataLine l = AudioSystem.getSourceDataLine(af); l.open(af); l.start();
                byte[] b = new byte[22050 * ms / 1000];
                for (int i = 0; i < b.length; i++) b[i] = (byte) (Math.sin(i * 2 * Math.PI * hz / 22050.0) * vol * 38 * (1 - i / (double) b.length));
                l.write(b, 0, b.length); l.drain(); l.close();
            } catch (Throwable ignored) {}
        });
    }
    void toast(String s) { toasts.add(new Toast(s)); if (toasts.size() > 5) toasts.remove(0); }
    void read(String title, String... lines) { roTitle = title; roLines = Arrays.asList(lines); }

    // ======================================================== SCROLLABLE & HIGH-READABILITY TERMINAL
    void tp(String s) {
        for (String ln : s.split("\n", -1)) tl.add(ln);
        while (tl.size() > 600) tl.remove(0);
        termScroll = 0; // Auto-snap to bottom when new output arrives
    }

    void scrollTerminal(int deltaLines) {
        int maxScroll = Math.max(0, termTotalRows - termMaxRows);
        termScroll = Math.max(0, Math.min(maxScroll, termScroll + deltaLines));
    }

    List<String> files(boolean all) {
        List<String> f = new ArrayList<>();
        if (w.f("file.lab")) f.add("lab.enc");
        if (w.f("file.forum")) f.add("forum.log");
        if (w.f("file.wall")) f.add("wall.enc");
        if (w.f("panel_open")) f.add("node.cfg");
        if (w.f("file.power")) f.add("power.map");
        if (w.f("file.archive")) f.add("genesis.dat");
        if (all && clues.has("c_lo")) f.add(".root");
        return f;
    }

    String commandManual(String topic) {
        return switch (topic.toLowerCase()) {
            case "help" -> """
                    [HDR] == MH-DECK COMMANDS (type 'help <cmd>') ==

                    [SEC] [1] RECON & FILES
                    [CMD]   ls -a          -> List captured & hidden files
                    [CMD]   cat <file>     -> Read a file (e.g. cat lab.enc)
                    [CMD]   scan           -> Inspect nearest room object
                    [CMD]   hint           -> Show current chapter puzzle hint
                    [CMD]   clear / exit   -> Clear screen / close terminal

                    [SEC] [2] CIPHERS & FORENSICS
                    [CMD]   decode <N> <T> -> Shift letters back by N places
                    [CMD]   whois <user>   -> Check account record (null, ghost_77)
                    [CMD]   trace thread   -> Verify Forum #4471 origin console

                    [SEC] [3] HARDWARE & NETWORK
                    [CMD]   unlock <HEX>   -> Open Node 0x01 keypad (e.g. 7A3F)
                    [CMD]   node <mode>    -> Set Node 0x01: purge|mirror|release
                    [CMD]   route <A> <B>  -> Bridge substation (route aux3 gate9)
                    [CMD]   sync <HZ>      -> Lock wave frequency (sync 432)
                    [CMD]   decrypt <KEY>  -> Open Genesis Monolith (1969-01)

                    [SEC] [4] ROOT CORE ENDINGS (Ch.6)
                    [CMD]   shutdown | takeover | loop | merge
                    [CMD]   transmit <WORD> -> Complete 1969 packet""";
            case "ls" -> """
                    [HDR] MANUAL: ls [-a]
                    [OUT] Lists data files captured from room terminals.
                    [TIP] Add '-a' to expose hidden system dotfiles (like .root).""";
            case "cat" -> """
                    [HDR] MANUAL: cat <filename>
                    [OUT] Displays the contents of a captured local file.
                    [TIP] Example: cat lab.enc  |  cat forum.log""";
            case "scan" -> """
                    [HDR] MANUAL: scan
                    [OUT] Scans the nearest interactive device within 140px
                    [OUT] for hidden metadata, lock status, or puzzle hints.""";
            case "decode" -> """
                    [HDR] MANUAL: decode <shift> <CIPHERTEXT>
                    [OUT] Reverses a Caesar cipher by shifting each letter
                    [OUT] backward <shift> steps in the alphabet.
                    [TIP] Example: decode 5 """ + LAB_ENC;
            case "whois" -> """
                    [HDR] MANUAL: whois <account>
                    [OUT] Queries user registry creation & deletion dates.
                    [TIP] Known handles: ghost_77, v0id_, null, imp_1969""";
            case "trace" -> """
                    [HDR] MANUAL: trace thread
                    [OUT] Inspects packet headers on Forum Thread #4471 to
                    [OUT] reveal which physical console authored the post.""";
            case "unlock" -> """
                    [HDR] MANUAL: unlock <4-hex-digits>
                    [OUT] Submits a 4-character hex handshake code to unseal
                    [OUT] concealed hardware panels (e.g. unlock 7A3F).""";
            case "node" -> """
                    [HDR] MANUAL: node <purge | mirror | release>
                    [OUT] Sets Node 0x01's administrative fate once active:
                    [CMD]   purge   -> Wipe the Dead Forum permanently
                    [CMD]   mirror  -> Clone your 'visitor_0' handle inside
                    [CMD]   release -> Preserve the forum & open the path""";
            case "route" -> """
                    [HDR] MANUAL: route <source> <target>
                    [OUT] Bridges substation power across healthy relays.
                    [TIP] Example: route aux3 gate9""";
            case "sync" -> """
                    [HDR] MANUAL: sync <frequency_hz>
                    [OUT] Tunes the Ghost Network carrier wave oscillator.
                    [TIP] Example: sync 432""";
            case "decrypt" -> """
                    [HDR] MANUAL: decrypt <YYYY-NN>
                    [OUT] Unlocks the Genesis Monolith archive vault.
                    [TIP] Example: decrypt 1969-01""";
            case "transmit", "shutdown", "takeover", "loop", "merge" -> """
                    [HDR] MANUAL: ROOT CORE VERDICTS (Ch.6)
                    [CMD]   shutdown       -> Ending 1: Disconnect & escape
                    [CMD]   takeover       -> Ending 2: Seize root control
                    [CMD]   loop           -> Ending 3: Restart 03:12 AM loop
                    [CMD]   merge          -> Ending 4: Fuse with visitor_0
                    [CMD]   transmit LOGIN -> Ending 5: Finish 1969 handshake""";
            default -> "[ERR] No manual entry for '" + topic + "'. Type 'help' to list commands.";
        };
    }

    void exec(String raw) {
        String line = raw.trim();
        tp("");
        tp("[IN]  > " + raw);
        if (line.isEmpty()) return;
        hist.add(line); hpos = hist.size();
        String[] t = line.split("\\s+", 3); String c = t[0].toLowerCase();
        switch (c) {
            case "help", "man" -> tp(commandManual(t.length > 1 ? t[1] : "help"));
            case "clear" -> { tl.clear(); termScroll = 0; }
            case "exit" -> termOpen = false;
            case "ls" -> {
                List<String> f = files(t.length > 1 && t[1].equals("-a"));
                if (f.isEmpty()) tp("[OUT] (no files captured yet — interact with room terminals)");
                else {
                    tp("[OUT] CAPTURED FILES: " + String.join("  |  ", f));
                    tp("[TIP] Run 'cat <filename>' to inspect contents.");
                }
            }
            case "cat" -> {
                if (t.length < 2) { tp("[ERR] Usage: cat <filename>  (run 'ls -a' first)"); break; }
                String f = t[1];
                if (!files(true).contains(f)) { tp("[ERR] File '" + f + "' not found locally."); break; }
                switch (f) {
                    case "lab.enc" -> {
                        tp("[HDR] FILE: lab.enc (Caesar Cipher)");
                        tp("[OUT] " + LAB_ENC);
                        tp("[TIP] Run: decode 5 " + LAB_ENC);
                    }
                    case "wall.enc" -> {
                        tp("[HDR] FILE: wall.enc (ROT+3 Graffiti)");
                        tp("[OUT] " + WALL_ENC);
                        tp("[TIP] Run: decode 3 " + WALL_ENC);
                    }
                    case "forum.log" -> {
                        tp("[HDR] FILE: forum.log (Thread #4471)");
                        for (String s : forumLines()) tp("[OUT] " + s);
                        tp("[TIP] Run 'trace thread' to verify origin console.");
                    }
                    case "node.cfg" -> {
                        tp("[HDR] FILE: node.cfg (Node 0x01 Control)");
                        tp("[OUT] Valid verdicts: purge | mirror | release");
                        tp("[TIP] Run: node release  (or purge / mirror)");
                    }
                    case "power.map" -> {
                        tp("[HDR] FILE: power.map (Substation Schematic)");
                        tp("[OUT] FAULT: BREAKER-B SHORTED");
                        tp("[OUT] READY: AUX-3 -> RELAYS 1,3,4,6 -> GATE-9");
                        tp("[TIP] Run: route aux3 gate9");
                    }
                    case "genesis.dat" -> {
                        tp("[HDR] FILE: genesis.dat (ARPANET Node 1)");
                        tp("[OUT] FOUNDED: 1969  //  NODE ID: 01");
                        tp("[TIP] Run: decrypt 1969-01");
                    }
                    case ".root" -> {
                        tp("[HDR] FILE: .root (Hidden 1969 Socket Log)");
                        tp("[OUT] 'It never died. Stopped mid-word after LO on Oct 29, 1969.'");
                        clues.find("c5_imp");
                    }
                }
            }
            case "scan" -> {
                Obj b = nearest(140);
                if (b == null || b.scan == null) tp("[ERR] No interactive target within 140px. Walk closer.");
                else {
                    tp("[HDR] SCAN TARGET: " + b.name);
                    tp("[OUT] " + b.scan);
                }
            }
            case "decode" -> {
                if (t.length < 3) { tp("[ERR] Usage: decode <shift> <text>"); break; }
                int n; try { n = Integer.parseInt(t[1]); } catch (Exception e) { tp("[ERR] Shift must be a number (0-25)."); break; }
                String out = caesar(t[2].toUpperCase(), -n);
                tp("[OUT] DECODED (-" + n + "): " + out);
                if (chapter == 1 && puz.attempt("p1_hatch", out) == 2) tp("[OK]  SUCCESS: Eastern floor hatch unsealed!");
                if (chapter == 2 && puz.attempt("p_wall", out) == 2) tp("[OK]  SUCCESS: Cafe wall cipher solved!");
            }
            case "whois" -> {
                if (t.length < 2) { tp("[ERR] Usage: whois <ghost_77 | v0id_ | null | imp_1969>"); break; }
                switch (t[1].toLowerCase()) {
                    case "ghost_77", "v0id_" -> {
                        tp("[HDR] WHOIS: " + t[1]);
                        tp("[OUT] STATUS: ARCHIVED 2014-03-02 (POSTING REVOKED)");
                        tp("[TIP] Anomaly: Account was deleted years before today's post!");
                        clues.find("c_whois");
                    }
                    case "null" -> {
                        tp("[HDR] WHOIS: NULL");
                        tp("[OUT] ROLE: SYSTEM MODERATOR (SINCE 1999)");
                        tp("[OUT] CONSOLE: CAFE-TERM-03");
                    }
                    case "imp_1969" -> {
                        tp("[HDR] WHOIS: imp_1969");
                        tp("[OUT] ROLE: ORIGINAL ARPANET ARCHITECT");
                        tp("[OUT] LAST PACKET: 'LO' (1969-10-29 22:30 PST)");
                        clues.find("c5_imp");
                    }
                    default -> tp("[ERR] Unknown user '" + t[1] + "'. Try: ghost_77, v0id_, null, imp_1969");
                }
            }
            case "trace" -> {
                if (t.length < 2 || !t[1].equalsIgnoreCase("thread")) { tp("[ERR] Usage: trace thread"); break; }
                if (!clues.has("c_forum")) { tp("[ERR] Inspect the Forum Terminal first to capture thread #4471."); break; }
                tp("[HDR] PACKET TRACE // THREAD #4471");
                tp("[OUT] ORIGIN CONSOLE: CAFE-TERM-03 (NULL's local terminal!)");
                tp("[OK]  Clue logged: Thread #4471 was staged locally.");
                clues.find("c_trace");
            }
            case "hint" -> tp("[TIP] " + puz.hint(chapter));
            case "unlock" -> {
                if (t.length < 2) { tp("[ERR] Usage: unlock <4-hex-digits>  (e.g. unlock 7A3F)"); break; }
                int r = puz.attempt("p_node", t[1]);
                if (r == 2) tp("[OK]  HANDSHAKE 7A3F ACCEPTED! Concealed Node 0x01 unsealed.");
                else if (r == 0) tp("[ERR] Inspect the Vending Machine & Signal Rates poster first.");
                else tp("[ERR] Invalid hex key '" + t[1] + "'.");
            }
            case "node" -> {
                if (!w.f("node_active")) { tp("[ERR] Unlock and activate Node 0x01 first."); break; }
                String opt = t.length > 1 ? t[1].toLowerCase() : "";
                switch (opt) {
                    case "purge" -> { w.set("purged", true); w.set("decided", true); tp("[OK]  VERDICT: PURGED. Dead Forum wiped."); }
                    case "mirror" -> { w.set("mirrored", true); w.set("decided", true); tp("[OK]  VERDICT: MIRRORED as visitor_0."); }
                    case "release" -> { w.set("released", true); w.set("decided", true); tp("[OK]  VERDICT: RELEASED. Forum preserved."); }
                    default -> tp("[ERR] Usage: node <purge | mirror | release>");
                }
            }
            case "route" -> {
                String arg = (t.length > 1 ? t[1] : "") + (t.length > 2 ? " " + t[2] : "");
                if (puz.attempt("p3_power", arg.trim()) == 2) tp("[OK]  CIRCUIT CLOSED: AUX-3 -> GATE-9 ONLINE!");
                else tp("[ERR] Invalid route. Usage: route aux3 gate9");
            }
            case "sync" -> {
                if (t.length < 2) { tp("[ERR] Usage: sync <hz>  (e.g. sync 432)"); break; }
                if (puz.attempt("p4_phase", t[1]) == 2) tp("[OK]  HARMONIC LOCK: 432 Hz stabilized!");
                else tp("[ERR] Phase mismatch at " + t[1] + " Hz.");
            }
            case "decrypt" -> {
                if (t.length < 2) { tp("[ERR] Usage: decrypt <key>  (e.g. decrypt 1969-01)"); break; }
                if (puz.attempt("p5_archive", t[1]) == 2) tp("[OK]  VAULT OPEN: Terminal imp_1969 unlocked!");
                else tp("[ERR] Key '" + t[1] + "' rejected.");
            }
            case "shutdown" -> { if (chapter == 6) triggerEnding(0); else tp("[ERR] Available only at Root Core (Ch.6)."); }
            case "takeover" -> { if (chapter == 6) triggerEnding(1); else tp("[ERR] Available only at Root Core (Ch.6)."); }
            case "loop" -> { if (chapter == 6) triggerEnding(2); else tp("[ERR] Available only at Root Core (Ch.6)."); }
            case "merge" -> {
                if (chapter == 6 && w.f("mirrored") && clues.has("c4_ghost_id")) triggerEnding(3);
                else tp("[ERR] Requires mirrored handle + ghost identity trace at Root Core.");
            }
            case "transmit" -> {
                if (chapter != 6) { tp("[ERR] Root Core socket required (Ch.6)."); break; }
                String word = t.length > 1 ? t[1] : "";
                boolean readyTrue = clues.has("c_lo") && clues.has("c3_tape") && clues.has("c5_imp") && (clues.has("c_confess") || clues.has("c3_null_log"));
                if (word.equalsIgnoreCase("LOGIN") && readyTrue) triggerEnding(4);
                else if (word.equalsIgnoreCase("LOGIN")) tp("[ERR] Evidence chain incomplete. Gather the 1969 clues across chapters.");
                else tp("[ERR] Invalid handshake word '" + word + "'.");
            }
            default -> tp("[ERR] Unknown command '" + c + "'. Type 'help' or click a button above.");
        }
    }

    Obj nearest(double range) {
        Obj best = null; double bd = 1e9;
        for (Obj b : objs) {
            if (!b.vis.get() || Math.abs(py - b.floor) > 18) continue;
            double d = Math.abs(px - b.cx()) - b.w / 2.0;
            if (d < range && d < bd) { bd = d; best = b; }
        }
        return best;
    }

    // ======================================================== UPDATE LOOP
    public void actionPerformed(ActionEvent e) {
        tick++;
        if (blinkT > 0) blinkT--; else if (rnd.nextInt(190) == 0) blinkT = 8;
        if (glitch > 0) glitch--; else if (glitchOn && state == PLAY && rnd.nextInt(850) == 0) glitch = 6;
        if (state != PLAY) {
            for (double[] n : net) {
                n[0] += n[2]; n[1] += n[3];
                if (n[0] < 0 || n[0] > W) n[2] = -n[2];
                if (n[1] < 0 || n[1] > H) n[3] = -n[3];
            }
        } else updatePlay();
        for (Iterator<Toast> it = toasts.iterator(); it.hasNext(); ) if (--it.next().life < 0) it.remove();
        if (jMsgT > 0) jMsgT--;
        repaint();
    }

    boolean platActive(int[] p) {
        if (p[3] == 0 || puz.done("p4_phase")) return true;
        int phase = (tick / 110) % 2;
        return (p[3] == 1 && phase == 0) || (p[3] == 2 && phase == 1);
    }

    void updatePlay() {
        playTicks++;
        int worldW = CH_WORLDS[chapter];
        termAnim += ((termOpen ? 1 : 0) - termAnim) * 0.22;
        lm += ((w.f("node_active") ? 1 : 0) - lm) * 0.025;
        pass += ((w.f("node_active") ? 1 : 0) - pass) * 0.03;

        boolean frozen = roLines != null || visPuzzle != null || dlg.cur != null || termOpen || journal || mapOpen;
        if (frozen || left || right) walkTargetX = -1;

        int dir = frozen ? 0 : (right ? 1 : 0) - (left ? 1 : 0);
        if (dir == 0 && walkTargetX >= 0 && !frozen) {
            double dx = walkTargetX - px;
            if (Math.abs(dx) > 5) dir = dx > 0 ? 1 : -1;
            else walkTargetX = -1;
        }

        crouch = !frozen && down && onGround && !climbing;
        double speed = crouch ? 1.5 : 3.7;
        if (dir != 0) face = dir;
        px = Math.max(28, Math.min(worldW - 28, px + dir * speed));

        int activeLadderX = -1, ladTop = 0, ladBot = FLOOR;
        for (int[] l : ladders) if (Math.abs(px - l[0]) < 16) { activeLadderX = l[0]; ladTop = l[1]; ladBot = l[2]; break; }

        if (!frozen && activeLadderX > 0 && !climbing && ((up && py > ladTop + 2) || (down && Math.abs(py - ladTop) < 4))) {
            climbing = true; px = activeLadderX; vy = 0;
        }
        if (climbing) {
            if (!frozen) {
                py += (down ? 3.2 : 0) - (up ? 3.2 : 0);
                if (dir != 0 && activeLadderX < 0) climbing = false;
                if (py <= ladTop) { py = ladTop; climbing = false; onGround = true; }
                if (py >= ladBot) { py = ladBot; climbing = false; onGround = true; }
            }
        } else {
            if (!frozen && up && onGround && !crouch && activeLadderX < 0) { vy = -12.8; onGround = false; }
            double old = py; vy += 0.62; py += vy; onGround = false;
            for (int[] p : plats) {
                if (!platActive(p)) continue;
                if (vy >= 0 && old <= p[2] + 1.0 && py >= p[2] && px + 11 > p[0] && px - 11 < p[1]) {
                    py = p[2]; vy = 0; onGround = true;
                }
            }
            if (py >= FLOOR) { py = FLOOR; vy = 0; onGround = true; }
        }

        if (chapter == 2 && crouch && px > 125 && px < 225 && !w.f("glyph_seen")) {
            if (++crouchT > 95) { w.set("glyph_seen", true); toast("Phosphor pixels glint beneath the grate!"); tone(1500, 120, .4); }
        } else if (!w.f("glyph_seen")) crouchT = Math.max(0, crouchT - 2);

        if (chapter == 3 && crouch && px > 910 && px < 1010 && !w.f("ch3_secret_open")) {
            if (++crouchT > 95) { w.set("ch3_secret_open", true); toast("A false panel behind Rack-04 clicks open!"); tone(1400, 140, .45); }
        }

        if (chapter == 2) {
            int step = (tick % 200) / 40;
            if (step != lastStep) {
                lastStep = step;
                if (step < 4 && !w.f("purged") && Math.abs(px - 765) < 280) {
                    w.put("seen", w.i("seen") | (1 << step));
                    if (w.i("seen") == 15) clues.find("c_vend");
                }
            }
        }

        double target = px - (W - termAnim * TW) / 2.0;
        camX += (Math.max(0, Math.min(worldW - W, target)) - camX) * 0.12;
        for (int i = 0; i < rx.length; i++) {
            ry[i] += rs[i]; rx[i] -= 0.7;
            if (ry[i] > H) { ry[i] = -10; rx[i] = rnd.nextInt(W + 100); }
        }
    }

    // ======================================================== MOUSE & WHEEL INPUT
    @Override public void mouseWheelMoved(MouseWheelEvent e) {
        if (state == PLAY && termOpen) {
            // Wheel up (negative rotation) scrolls UP into older lines; wheel down scrolls toward bottom
            scrollTerminal(-e.getWheelRotation() * 3);
        }
    }

    @Override public void mouseMoved(MouseEvent e) {
        mouseX = e.getX(); mouseY = e.getY();
        hoverTip = null;
        for (int i = hitBoxes.size() - 1; i >= 0; i--) {
            HitBox hb = hitBoxes.get(i);
            if (hb.rect().contains(mouseX, mouseY)) {
                hoverTip = hb.tip();
                break;
            }
        }
        setCursor(Cursor.getPredefinedCursor(hoverTip != null ? Cursor.HAND_CURSOR : Cursor.DEFAULT_CURSOR));
    }
    @Override public void mouseDragged(MouseEvent e) { mouseMoved(e); }
    @Override public void mouseEntered(MouseEvent e) {}
    @Override public void mouseExited(MouseEvent e) { hoverTip = null; }
    @Override public void mouseReleased(MouseEvent e) {}
    @Override public void mouseClicked(MouseEvent e) {}

    @Override public void mousePressed(MouseEvent e) {
        requestFocusInWindow();
        int mx = e.getX(), my = e.getY();

        for (int i = hitBoxes.size() - 1; i >= 0; i--) {
            HitBox hb = hitBoxes.get(i);
            if (hb.rect().contains(mx, my)) {
                hb.action().run();
                return;
            }
        }

        if (state == PLAY && roLines == null && visPuzzle == null && dlg.cur == null && !termOpen && !journal && !mapOpen) {
            double worldClickX = mx + camX;
            for (Obj b : objs) {
                if (!b.vis.get()) continue;
                if (worldClickX >= b.x - 12 && worldClickX <= b.x + b.w + 12 && my >= b.floor - 210 && my <= b.floor + 10) {
                    if (Math.abs(px - b.cx()) - b.w / 2.0 < 62 && Math.abs(py - b.floor) <= 24) {
                        b.use.run();
                        tone(440, 35, .28);
                    } else {
                        walkTargetX = b.cx();
                        toast("Walking to " + b.name + "...");
                    }
                    return;
                }
            }
            if (my >= 130 && my <= FLOOR + 50) {
                walkTargetX = Math.max(32, Math.min(CH_WORLDS[chapter] - 32, worldClickX));
            }
        }
    }

    // ======================================================== KEYBOARD INPUT
    public void keyTyped(KeyEvent e) {
        if (state == PLAY && termOpen) {
            char c = e.getKeyChar();
            if (c >= 32 && c < 127 && tin.length() < 120) { tin.append(c); tone(1800, 10, .12); }
        }
    }
    public void keyReleased(KeyEvent e) {
        int k = e.getKeyCode();
        if (k == KeyEvent.VK_A || k == KeyEvent.VK_LEFT) left = false;
        if (k == KeyEvent.VK_D || k == KeyEvent.VK_RIGHT) right = false;
        if (k == KeyEvent.VK_W || k == KeyEvent.VK_UP || k == KeyEvent.VK_SPACE) up = false;
        if (k == KeyEvent.VK_S || k == KeyEvent.VK_DOWN) down = false;
    }

    public void keyPressed(KeyEvent e) {
        int k = e.getKeyCode();
        if (state == MENU) { menuKey(k); return; }
        if (state == SETTINGS) {
            if (k == KeyEvent.VK_ESCAPE) state = MENU;
            if (k == KeyEvent.VK_UP) ssel = (ssel + 2) % 3;
            if (k == KeyEvent.VK_DOWN) ssel = (ssel + 1) % 3;
            if (k == KeyEvent.VK_ENTER) { if (ssel == 0) crt = !crt; if (ssel == 1) glitchOn = !glitchOn; if (ssel == 2) soundOn = !soundOn; }
            return;
        }
        if (state == CREDITS) { state = MENU; return; }
        if (state == LOAD) {
            if (k == KeyEvent.VK_ESCAPE) state = MENU;
            if (k == KeyEvent.VK_UP) ssel = (ssel + 2) % 3;
            if (k == KeyEvent.VK_DOWN) ssel = (ssel + 1) % 3;
            if (k == KeyEvent.VK_ENTER && load(ssel)) state = PLAY;
            return;
        }
        if (state == END) { if (k == KeyEvent.VK_ENTER) state = MENU; return; }

        if (termOpen) {
            if (k == KeyEvent.VK_ESCAPE || k == KeyEvent.VK_TAB) termOpen = false;
            else if (k == KeyEvent.VK_ENTER) { exec(tin.toString()); tin.setLength(0); tone(600, 22, .18); }
            else if (k == KeyEvent.VK_BACK_SPACE && tin.length() > 0) tin.setLength(tin.length() - 1);
            else if (k == KeyEvent.VK_PAGE_UP) scrollTerminal(8);
            else if (k == KeyEvent.VK_PAGE_DOWN) scrollTerminal(-8);
            else if (k == KeyEvent.VK_UP && e.isShiftDown()) scrollTerminal(2);
            else if (k == KeyEvent.VK_DOWN && e.isShiftDown()) scrollTerminal(-2);
            else if (k == KeyEvent.VK_UP && hpos > 0) { hpos--; tin.setLength(0); tin.append(hist.get(hpos)); }
            else if (k == KeyEvent.VK_DOWN) { hpos = Math.min(hist.size(), hpos + 1); tin.setLength(0); if (hpos < hist.size()) tin.append(hist.get(hpos)); }
            else if (k == KeyEvent.VK_F2) TW = TW == 520 ? 640 : 520;
            return;
        }
        if (visPuzzle != null) { visualPuzzleKey(k); return; }
        if (journal) { journalKey(k); return; }
        if (mapOpen) { if (k == KeyEvent.VK_M || k == KeyEvent.VK_ESCAPE) mapOpen = false; return; }
        if (roLines != null) {
            if (k == KeyEvent.VK_E || k == KeyEvent.VK_ENTER || k == KeyEvent.VK_SPACE || k == KeyEvent.VK_ESCAPE) roLines = null;
            return;
        }
        if (dlg.cur != null) {
            if (k >= KeyEvent.VK_1 && k <= KeyEvent.VK_9 && !dlg.visible().isEmpty()) dlg.pick(k - KeyEvent.VK_1);
            else if (dlg.visible().isEmpty() && (k == KeyEvent.VK_E || k == KeyEvent.VK_ENTER || k == KeyEvent.VK_SPACE || k == KeyEvent.VK_ESCAPE)) dlg.cur = null;
            return;
        }

        switch (k) {
            case KeyEvent.VK_A, KeyEvent.VK_LEFT -> left = true;
            case KeyEvent.VK_D, KeyEvent.VK_RIGHT -> right = true;
            case KeyEvent.VK_W, KeyEvent.VK_UP, KeyEvent.VK_SPACE -> up = true;
            case KeyEvent.VK_S, KeyEvent.VK_DOWN -> down = true;
            case KeyEvent.VK_E -> { Obj b = nearest(52); if (b != null) { b.use.run(); tone(440, 35, .28); } }
            case KeyEvent.VK_TAB -> { termOpen = true; left = right = up = down = false; }
            case KeyEvent.VK_J -> { journal = true; left = right = up = down = false; }
            case KeyEvent.VK_M -> { mapOpen = true; left = right = up = down = false; }
            case KeyEvent.VK_F5 -> { save(slot); toast("SESSION SAVED (Slot " + (slot + 1) + ")"); }
            case KeyEvent.VK_F9 -> { if (load(slot)) toast("SESSION LOADED"); }
            case KeyEvent.VK_ESCAPE -> { save(slot); state = MENU; }
        }
    }

    void submitVisualPuzzle() {
        switch (visPuzzle) {
            case "ch1_cipher" -> {
                String decoded = caesar(LAB_ENC, -vpShift);
                if (puz.attempt("p1_hatch", decoded) == 2) visPuzzle = null;
                else { toast("Cipher ring misaligned (Shift: " + vpShift + ")"); tone(180, 90, .3); }
            }
            case "ch2_wall" -> {
                String decoded = caesar(WALL_ENC, -vpWallShift);
                if (puz.attempt("p_wall", decoded) == 2) visPuzzle = null;
                else { toast("Prism offset misaligned (ROT-" + vpWallShift + ")"); tone(180, 90, .3); }
            }
            case "ch2_keypad" -> {
                StringBuilder hex = new StringBuilder();
                for (int d : vpKeyDigits) hex.append(Integer.toHexString(d).toUpperCase());
                if (puz.attempt("p_node", hex.toString()) == 2) visPuzzle = null;
                else { toast("INVALID HEX KEY: " + hex); tone(160, 110, .35); }
            }
            case "ch3_circuit" -> {
                if (vpNodes[0] && !vpNodes[1] && vpNodes[2] && vpNodes[3] && vpNodes[5]) {
                    puz.attempt("p3_power", "aux3 gate9");
                    visPuzzle = null;
                } else if (vpNodes[1]) {
                    toast("SHORT CIRCUIT! Breaker-B (Node 2) is damaged—keep it OFF!");
                    tone(140, 140, .4);
                } else {
                    toast("INCOMPLETE CIRCUIT: Bridge AUX-3 to GATE-9.");
                    tone(190, 90, .3);
                }
            }
            case "ch4_wave" -> {
                if (puz.attempt("p4_phase", "" + vpFreq) == 2) visPuzzle = null;
                else { toast("PHASE DRIFT (" + vpFreq + " Hz) — Align waves at 432 Hz!"); tone(180, 100, .3); }
            }
            case "ch5_rings" -> {
                String code = "" + vpRings[0] + vpRings[1] + vpRings[2] + vpRings[3] + "-" + vpRings[4] + vpRings[5];
                if (puz.attempt("p5_archive", code) == 2) visPuzzle = null;
                else { toast("TUMBLER LOCKED (" + code + ")"); tone(170, 100, .3); }
            }
            case "ch6_core" -> {
                String word = "LO" + vpLetters[0] + vpLetters[1] + vpLetters[2];
                boolean readyTrue = clues.has("c_lo") && clues.has("c3_tape") && clues.has("c5_imp") && (clues.has("c_confess") || clues.has("c3_null_log"));
                if (word.equals("LOGIN") && readyTrue) triggerEnding(4);
                else if (word.equals("LOGIN")) { toast("SOCKET REJECTED: Cross-chapter evidence incomplete!"); tone(150, 130, .4); }
                else { toast("PACKET '" + word + "' INVALID"); tone(180, 90, .3); }
            }
        }
    }

    void visualPuzzleKey(int k) {
        if (k == KeyEvent.VK_ESCAPE) { visPuzzle = null; return; }
        if (k == KeyEvent.VK_ENTER) { submitVisualPuzzle(); return; }
        switch (visPuzzle) {
            case "ch1_cipher" -> {
                if (k == KeyEvent.VK_LEFT || k == KeyEvent.VK_A) { vpShift = (vpShift + 25) % 26; tone(720, 18, .2); }
                if (k == KeyEvent.VK_RIGHT || k == KeyEvent.VK_D) { vpShift = (vpShift + 1) % 26; tone(780, 18, .2); }
            }
            case "ch2_wall" -> {
                if (k == KeyEvent.VK_LEFT || k == KeyEvent.VK_A) { vpWallShift = (vpWallShift + 25) % 26; tone(760, 18, .2); }
                if (k == KeyEvent.VK_RIGHT || k == KeyEvent.VK_D) { vpWallShift = (vpWallShift + 1) % 26; tone(820, 18, .2); }
            }
            case "ch2_keypad" -> {
                if (k == KeyEvent.VK_LEFT || k == KeyEvent.VK_A) vpCursor = (vpCursor + 3) % 4;
                if (k == KeyEvent.VK_RIGHT || k == KeyEvent.VK_D) vpCursor = (vpCursor + 1) % 4;
                if (k == KeyEvent.VK_UP || k == KeyEvent.VK_W) { vpKeyDigits[vpCursor] = (vpKeyDigits[vpCursor] + 1) % 16; tone(900, 18, .2); }
                if (k == KeyEvent.VK_DOWN || k == KeyEvent.VK_S) { vpKeyDigits[vpCursor] = (vpKeyDigits[vpCursor] + 15) % 16; tone(840, 18, .2); }
            }
            case "ch3_circuit" -> {
                if (k == KeyEvent.VK_LEFT || k == KeyEvent.VK_A) vpCursor = (vpCursor + 5) % 6;
                if (k == KeyEvent.VK_RIGHT || k == KeyEvent.VK_D) vpCursor = (vpCursor + 1) % 6;
                if (k == KeyEvent.VK_SPACE || k == KeyEvent.VK_W || k == KeyEvent.VK_S) {
                    vpNodes[vpCursor] = !vpNodes[vpCursor];
                    tone(vpNodes[vpCursor] ? 1050 : 520, 22, .25);
                }
            }
            case "ch4_wave" -> {
                if (k == KeyEvent.VK_LEFT || k == KeyEvent.VK_A) { vpFreq = Math.max(360, vpFreq - 4); tone(vpFreq, 18, .2); }
                if (k == KeyEvent.VK_RIGHT || k == KeyEvent.VK_D) { vpFreq = Math.min(480, vpFreq + 4); tone(vpFreq, 18, .2); }
            }
            case "ch5_rings" -> {
                if (k == KeyEvent.VK_LEFT || k == KeyEvent.VK_A) vpCursor = (vpCursor + 5) % 6;
                if (k == KeyEvent.VK_RIGHT || k == KeyEvent.VK_D) vpCursor = (vpCursor + 1) % 6;
                if (k == KeyEvent.VK_UP || k == KeyEvent.VK_W) { vpRings[vpCursor] = (vpRings[vpCursor] + 1) % 10; tone(860, 18, .2); }
                if (k == KeyEvent.VK_DOWN || k == KeyEvent.VK_S) { vpRings[vpCursor] = (vpRings[vpCursor] + 9) % 10; tone(800, 18, .2); }
            }
            case "ch6_core" -> {
                if (k == KeyEvent.VK_LEFT || k == KeyEvent.VK_A) vpCursor = (vpCursor + 2) % 3;
                if (k == KeyEvent.VK_RIGHT || k == KeyEvent.VK_D) vpCursor = (vpCursor + 1) % 3;
                if (k == KeyEvent.VK_UP || k == KeyEvent.VK_W) { vpLetters[vpCursor] = (char) ('A' + (vpLetters[vpCursor] - 'A' + 1) % 26); tone(950, 18, .2); }
                if (k == KeyEvent.VK_DOWN || k == KeyEvent.VK_S) { vpLetters[vpCursor] = (char) ('A' + (vpLetters[vpCursor] - 'A' + 25) % 26); tone(890, 18, .2); }
                if (k == KeyEvent.VK_1) triggerEnding(0);
                if (k == KeyEvent.VK_2) triggerEnding(1);
                if (k == KeyEvent.VK_3) triggerEnding(2);
                if (k == KeyEvent.VK_4 && w.f("mirrored") && clues.has("c4_ghost_id")) triggerEnding(3);
            }
        }
    }

    void menuKey(int k) {
        if (k == KeyEvent.VK_UP) msel = (msel + 5) % 6;
        if (k == KeyEvent.VK_DOWN) msel = (msel + 1) % 6;
        if (k != KeyEvent.VK_ENTER) return;
        activateMenu(msel);
    }

    void activateMenu(int idx) {
        switch (idx) {
            case 0 -> { int s = newestSlot(); if (s >= 0 && load(s)) state = PLAY; }
            case 1 -> newGame();
            case 2 -> { state = LOAD; ssel = 0; }
            case 3 -> { state = SETTINGS; ssel = 0; }
            case 4 -> state = CREDITS;
            case 5 -> System.exit(0);
        }
    }

    void journalClickLink(int idx) {
        List<Clue> L = clues.found();
        if (idx < 0 || idx >= L.size()) return;
        jSel = idx;
        if (jFirst < 0) jFirst = jSel;
        else if (jFirst == jSel) jFirst = -1;
        else {
            String a = L.get(jFirst).id(), b = L.get(jSel).id(), key = ClueDB.key(a, b);
            if (w.f("link." + key)) jMsg = "Already linked on board.";
            else if (clues.insights.containsKey(key)) {
                w.set("link." + key, true); String ins = clues.insights.get(key); clues.find(ins);
                jMsg = "INSIGHT UNLOCKED: " + clues.defs.get(ins).title(); tone(988, 140, .45);
            } else { jMsg = "No direct correlation found between these two clues."; tone(150, 110, .35); }
            jMsgT = 220; jFirst = -1;
        }
    }

    void journalKey(int k) {
        List<Clue> L = clues.found(); int cols = 5;
        if (k == KeyEvent.VK_J || k == KeyEvent.VK_ESCAPE) { journal = false; jFirst = -1; return; }
        if (L.isEmpty()) return;
        jSel = Math.min(jSel, L.size() - 1);
        if (k == KeyEvent.VK_LEFT) jSel = Math.max(0, jSel - 1);
        if (k == KeyEvent.VK_RIGHT) jSel = Math.min(L.size() - 1, jSel + 1);
        if (k == KeyEvent.VK_UP) jSel = Math.max(0, jSel - cols);
        if (k == KeyEvent.VK_DOWN) jSel = Math.min(L.size() - 1, jSel + cols);
        if (k == KeyEvent.VK_ENTER) journalClickLink(jSel);
    }

    // ======================================================== RENDERING
    @Override protected void paintComponent(Graphics g0) {
        hitBoxes.clear();
        Graphics2D g = buf.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        switch (state) {
            case PLAY -> {
                drawScene(g);
                drawHud(g);
                if (visPuzzle != null) drawVisualPuzzle(g);
                if (journal) drawJournal(g);
                if (mapOpen) drawWorldMap(g);
                drawTerminal(g);
            }
            case END -> { drawNetwork(g); drawEnd(g); }
            default -> { drawNetwork(g); drawMenu(g); }
        }
        g.dispose();

        Graphics2D s = (Graphics2D) g0;
        s.drawImage(buf, 0, 0, null);
        if (glitchOn && glitch > 0) {
            for (int i = 0; i < 6; i++) {
                int y0 = snap(rnd.nextInt(H - 40)), h0 = snap(4 + rnd.nextInt(26)), dx = snap(rnd.nextInt(54) - 27);
                s.drawImage(buf, dx, y0, dx + W, y0 + h0, 0, y0, W, y0 + h0, null);
            }
            s.setColor(A(MG, 45)); s.fillRect(0, snap(rnd.nextInt(H)), W, 2 * PX);
        }
        if (crt) {
            s.setColor(new Color(0, 0, 0, 32));
            for (int y = 0; y < H; y += 3) s.fillRect(0, y, W, 1);
        }
        s.setPaint(new RadialGradientPaint(W / 2f, H / 2f, 760f, new float[]{0.58f, 1f}, new Color[]{new Color(0, 0, 0, 0), new Color(0, 0, 0, 125)}));
        s.fillRect(0, 0, W, H);
    }

    void drawBtn(Graphics2D g, int x, int y, int w, int h, String label, Color col, Runnable act, String tip) {
        boolean hov = mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
        Color fill = hov ? A(col, 95) : new Color(16, 22, 48, 240);
        pxRect(g, x, y, w, h, fill, hov ? Color.WHITE : col, new Color(6, 10, 22));
        g.setColor(hov ? Color.WHITE : col);
        g.drawRect(x, y, w - 1, h - 1);
        g.setFont(SMALL);
        int tw = g.getFontMetrics().stringWidth(label);
        drawPixelText(g, label, x + (w - tw) / 2, y + h / 2 + 4, hov ? Color.WHITE : col, Color.BLACK);
        regHit(x, y, w, h, act, tip);
    }

    void box(Graphics2D g, int x, int y, int w, int h, Color border) {
        pxFrame(g, x, y, w, h, new Color(12, 16, 38, 242), border);
    }

    List<String> wrap(String s, FontMetrics fm, int maxW) {
        List<String> out = new ArrayList<>();
        for (String para : s.split("\n", -1)) {
            if (para.isEmpty()) { out.add(""); continue; }
            StringBuilder cur = new StringBuilder();
            int indent = 0;
            while (indent < para.length() && para.charAt(indent) == ' ') indent++;
            String pad = " ".repeat(indent);
            for (String wd : para.trim().split(" ")) {
                String test = cur.length() == 0 ? pad + wd : cur + " " + wd;
                if (fm.stringWidth(test) > maxW && cur.length() > 0) {
                    out.add(cur.toString());
                    cur = new StringBuilder(pad + wd);
                } else {
                    cur = new StringBuilder(test);
                }
            }
            out.add(cur.toString());
        }
        return out;
    }

    void glow(Graphics2D g, double x, double y, float r, Color c, int a) {
        int gx = snap(x), gy = snap(y), gr = snap(r);
        g.setColor(A(c, a / 4));
        g.fillOval(gx - gr, gy - gr, gr * 2, gr * 2);
        g.setColor(A(c, a / 2));
        g.fillOval(gx - (gr * 2) / 3, gy - (gr * 2) / 3, (gr * 4) / 3, (gr * 4) / 3);
        g.setColor(A(c, a));
        g.fillOval(gx - gr / 3, gy - gr / 3, (gr * 2) / 3, (gr * 2) / 3);
    }

    void sym(Graphics2D g, int idx, double cx, double cy, double r, Color c) {
        g.setColor(c);
        int x = snap(cx), y = snap(cy), ir = snap(r);
        switch (idx) {
            case 0 -> g.fillPolygon(new int[]{x, x - ir, x + ir}, new int[]{y - ir, y + ir, y + ir}, 3);
            case 1 -> g.fillOval(x - ir, y - ir, 2 * ir, 2 * ir);
            case 2 -> g.fillRect(x - ir, y - ir, 2 * ir, 2 * ir);
            default -> g.fillPolygon(new int[]{x, x + ir, x, x - ir}, new int[]{y - ir, y, y + ir, y}, 4);
        }
    }

    void drawConduitPulse(Graphics2D g, int x1, int y1, int x2, int y2, Color c, boolean active) {
        g.setColor(active ? A(c, 210) : new Color(48, 56, 92));
        if (x1 == x2 || y1 == y2) {
            int rx = Math.min(x1, x2), ry = Math.min(y1, y2);
            int rw = Math.max(2 * PX, Math.abs(x2 - x1)), rh = Math.max(2 * PX, Math.abs(y2 - y1));
            g.fillRect(rx, ry, rw, rh);
        } else {
            int midX = snap((x1 + x2) / 2.0);
            g.fillRect(Math.min(x1, midX), y1 - PX, Math.abs(midX - x1) + PX, 2 * PX);
            g.fillRect(midX - PX, Math.min(y1, y2), 2 * PX, Math.abs(y2 - y1) + PX);
            g.fillRect(Math.min(midX, x2), y2 - PX, Math.abs(x2 - midX) + PX, 2 * PX);
        }
        if (active) {
            double t = (tick * 0.022) % 1.0;
            int px0 = snap(x1 + (x2 - x1) * t);
            int py0 = snap(y1 + (y2 - y1) * t);
            glow(g, px0, py0, 12, c, 210);
            g.setColor(Color.WHITE);
            g.fillRect(px0 - PX, py0 - PX, 2 * PX, 2 * PX);
        }
    }

    Color chapterAccent() {
        return switch (chapter) {
            case 1 -> CY;
            case 2 -> mix(MG, GR, lm);
            case 3 -> AM;
            case 4 -> VI;
            case 5 -> CY;
            default -> GR;
        };
    }

    // ======================================================== VIBRANT TWILIGHT CYBERPUNK PIXEL-ART SCENE
    void drawScene(Graphics2D g) {
        double cx = camX;
        int worldW = CH_WORLDS[chapter];
        Color acc = chapterAccent();

        // Rich twilight indigo -> violet -> hot magenta-pink horizon sky (matching the reference images!)
        int bands = 18;
        for (int b = 0; b < bands; b++) {
            double t = b / (double) (bands - 1);
            Color c = t < 0.55 ? mix(SKY_TOP, SKY_MID, t / 0.55) : mix(SKY_MID, SKY_HORIZON, (t - 0.55) / 0.45);
            g.setColor(c);
            int y0 = (b * H) / bands, y1 = ((b + 1) * H) / bands;
            g.fillRect(0, y0, W, y1 - y0);
        }

        // Pixel-art twilight moon & twinkling stars (from reference image 2)
        int moonX = snap(920 - cx * 0.06), moonY = 92;
        g.setColor(new Color(175, 130, 235, 130));
        g.fillOval(moonX - 44, moonY - 44, 88, 88);
        g.setColor(new Color(205, 165, 255, 165));
        g.fillOval(moonX - 34, moonY - 34, 68, 68);
        for (int st = 0; st < 28; st++) {
            int sx = snap((st * 97 - cx * 0.08 + W * 2) % W);
            int sy = snap(18 + (st * 43) % 160);
            g.setColor(((tick / 24 + st) % 4 == 0) ? Color.WHITE : new Color(210, 190, 255, 180));
            g.fillRect(sx, sy, PX, PX);
        }

        // Far silhouette skyline in deep royal purple
        for (int i = 0; i < 16; i++) {
            int bx = snap(i * 110 - cx * 0.14);
            int bw = snap(70 + (i * 29 % 44));
            int bh = snap(180 + (i * 53 % 160));
            g.setColor(new Color(52, 34, 108));
            g.fillRect(bx, FLOOR - bh - 50, bw, bh + 50);
            if (i == 4) {
                // Digital clock tower detail ("19:69" / "03:12")
                pxFrame(g, bx + 12, FLOOR - bh - 34, bw - 24, 22, new Color(36, 22, 82), VI);
                g.setFont(SMALL); g.setColor(VI);
                g.drawString("03:12", bx + 18, FLOOR - bh - 19);
            }
        }

        // Midground cobalt-blue & violet cyberpunk towers with glowing neon signs & vertical kanji/text banners
        String[] signs = {"RANGO", "VACANCY", "NET-01", "CYBER", "NODE", "1969", "DATA", "VOID"};
        Color[] signCols = {AM, GR, CY, MG, CY, AM, MG, GR};
        for (int i = 0; i < 16; i++) {
            int bx = snap(i * 155 - cx * 0.28);
            int bw = snap(88 + (i * 37 % 48));
            int bh = snap(240 + (i * 71 % 190));
            int topY = FLOOR - bh - 30;
            pxRect(g, bx, topY, bw, bh + 30, BLDG_BLUE, BL, BLDG_DARK);

            // Pixel-art rooftop AC units & antennas
            if (i % 2 == 0) {
                pxRect(g, bx + 14, topY - 18, 28, 18, new Color(95, 120, 175), Color.WHITE, BLDG_DARK);
                g.setColor(BLDG_DARK); g.fillOval(bx + 20, topY - 14, 12, 12);
            } else {
                g.setColor(BL);
                g.fillRect(bx + bw / 2 - PX, topY - 38, 2 * PX, 38);
                if ((tick / 20 + i) % 2 == 0) glow(g, bx + bw / 2.0, topY - 38, 12, MG, 190);
            }

            // Glowing violet/cyan pixel-art windows with diagonal glint
            for (int r = 0; r < bh / 22; r++) {
                for (int col = 0; col < 2; col++) {
                    int wx = bx + 14 + col * 34;
                    int wy = topY + 18 + r * 22;
                    if (wx + 24 < bx + bw - 8) {
                        boolean bright = ((i + r * 3 + col) % 5) == 0;
                        pxRect(g, wx, wy, 24, 14, bright ? new Color(180, 235, 255) : WIN_VIOLET, BLDG_DARK, BL);
                        if (!bright) {
                            g.setColor(new Color(145, 115, 205));
                            g.fillRect(wx + 6, wy + 4, PX, PX);
                            g.fillRect(wx + 10, wy + 8, PX, PX);
                        }
                    }
                }
            }

            // Vertical neon signs (inspired by "RANGO" & "VACANCY" signs in uploaded images)
            if (i % 2 == 1) {
                int sx = bx + bw - 18, sy = topY + 34, sh = 96;
                Color sc = signCols[i % signCols.length];
                pxFrame(g, sx, sy, 22, sh, new Color(24, 14, 58), sc);
                g.setFont(SMALL);
                String word = signs[i % signs.length];
                for (int ch = 0; ch < Math.min(5, word.length()); ch++) {
                    drawPixelText(g, "" + word.charAt(ch), sx + 7, sy + 18 + ch * 16, sc, Color.BLACK);
                }
            }
        }

        // Elevated monorail track & sagging pixel cables across midground
        int railY = 232;
        pxRect(g, 0, railY, W, 12, BLDG_BLUE, CY, BLDG_DARK);
        for (int p = 0; p < 8; p++) {
            int px0 = snap(p * 240 - cx * 0.42);
            pxRect(g, px0, railY + 12, 14, FLOOR - railY - 12, BLDG_BLUE, BL, BLDG_DARK);
        }
        for (int s = 0; s < 9; s++) {
            int sx = snap(s * 280 - cx * 0.5);
            int sag = snap(52 + (s % 3) * 20);
            g.setColor(BLDG_DARK);
            for (int step = 0; step < 28; step++) {
                double t = step / 28.0;
                g.fillRect(sx + step * 10, railY + 12 + snap(4 * sag * t * (1 - t)), 10, 2 * PX);
            }
        }

        drawHoloSign(g, snap(360 - cx * 0.65), 146, chapter == 1 ? "LAB // 04" : chapter == 2 ? "RANGO CAFE" : chapter == 3 ? "RACK-00" : chapter == 4 ? "GHOST // 432" : chapter == 5 ? "1969 ROOT" : "CORE 0x00", AM);
        drawHoloSign(g, snap(1080 - cx * 0.65), 166, chapter % 2 == 0 ? "OPEN 24H" : "DEEP WIRE", MG);

        g.translate(-snap(cx), 0);

        // Foreground cyberpunk street-level storefront & structural architecture (deep navy-indigo with neon trim)
        g.setColor(new Color(16, 22, 52, 228));
        g.fillRect(0, 124, worldW, FLOOR - 124);
        // Mint + Pink neon awning trim (from reference image 2's convenience store roof!)
        for (int x = 0; x < worldW; x += 260) {
            pxRect(g, x, 124, 24, FLOOR - 124, BLDG_DARK, BL, new Color(8, 12, 30));
            pxRect(g, x + 24, 134, 236, 6, GR, Color.WHITE, null);
            pxRect(g, x + 24, 140, 236, 6, MG, null, null);
        }
        // Subtle pixel brick lines
        g.setColor(new Color(28, 38, 82, 130));
        for (int by = 160; by < FLOOR; by += 24) {
            g.fillRect(0, by, worldW, PX);
        }

        // Pixel-art sidewalk / deck platform floor with cyan & magenta edge lighting
        g.setColor(new Color(14, 20, 46));
        g.fillRect(0, FLOOR, worldW, H - FLOOR);
        g.setColor(CY);
        g.fillRect(0, FLOOR, worldW, 2 * PX);
        g.setColor(BLDG_BLUE);
        g.fillRect(0, FLOOR + 2 * PX, worldW, 4 * PX);
        g.setColor(MG);
        g.fillRect(0, FLOOR + 6 * PX, worldW, PX);
        g.setColor(A(CY, 75));
        for (int tx = 0; tx < worldW; tx += 36) {
            g.fillRect(tx, FLOOR + 2 * PX, PX, H - FLOOR);
        }
        for (int x = 160; x < worldW - 120; x += 310) {
            g.setColor(A(CY, 55));
            g.fillRect(x, FLOOR + 18, 130, 6);
            g.setColor(A(MG, 45));
            g.fillRect(x + 36, FLOOR + 32, 90, 4);
        }

        drawEnvironmentalPuzzleVisuals(g);

        // Pixel-art ladders
        for (int[] l : ladders) {
            g.setColor(new Color(120, 155, 220));
            g.fillRect(l[0] - 10, l[1], 2 * PX, l[2] - l[1]);
            g.fillRect(l[0] + 8, l[1], 2 * PX, l[2] - l[1]);
            for (int y = l[1] + 12; y < l[2]; y += 16) {
                g.fillRect(l[0] - 10, y, 22, 2 * PX);
            }
        }

        // Pixel-art platforms
        for (int[] p : plats) {
            boolean active = platActive(p);
            if (active) {
                pxRect(g, p[0], p[2], p[1] - p[0], 12, p[3] > 0 ? new Color(56, 30, 108) : BLDG_BLUE, p[3] > 0 ? VI : CY, BLDG_DARK);
            } else {
                g.setColor(A(VI, 80));
                g.drawRect(p[0], p[2], p[1] - p[0], 12);
            }
        }

        for (Obj b : objs) {
            if (!b.vis.get()) continue;
            drawObject(g, b);
        }

        if (walkTargetX >= 0) {
            int wx = snap(walkTargetX);
            g.setColor(CY);
            g.drawRect(wx - 10, FLOOR - 4, 20, 8);
            g.fillRect(wx - 2, FLOOR - 8, 4, 4);
        }

        if (w.f("mirrored") && (chapter == 2 || chapter == 6)) {
            drawGirlPlayer(g, chapter == 2 ? 350 : 840, FLOOR, -1, false, false, 0.35f);
        }

        boolean moving = (Math.abs((right ? 1 : 0) - (left ? 1 : 0)) > 0 || walkTargetX >= 0)
                && roLines == null && visPuzzle == null && !termOpen && !journal && !mapOpen;
        drawGirlPlayer(g, px, py, face, crouch, moving, 1.0f);

        g.translate(snap(cx), 0);

        // Luminous pixel snow/rain motes floating in the neon air
        g.setFont(SMALL);
        for (int i = 0; i < rx.length; i++) {
            int rxx = snap(rx[i]), ryy = snap(ry[i]);
            if (i % 5 == 0) {
                g.setColor(A(Color.WHITE, 165));
                g.fillRect(rxx, ryy, PX, PX);
            } else {
                g.setColor(A(CY, 75));
                g.fillRect(rxx, ryy, PX, 4 * PX);
            }
        }

        drawLighting(g, snap(cx), acc);
    }

    void drawEnvironmentalPuzzleVisuals(Graphics2D g) {
        switch (chapter) {
            case 1 -> {
                boolean solved = puz.done("p1_hatch");
                drawConduitPulse(g, 285, FLOOR - 45, 470, FLOOR - 150, CY, clues.has("c1_note"));
                drawConduitPulse(g, 645, FLOOR - 150, 1480, FLOOR - 150, solved ? GR : RD, solved);
                for (int i = 0; i < 4; i++) {
                    int bx = 1492 + i * 24, by = FLOOR - 210;
                    pxRect(g, bx, by, 14, 14, solved ? GR : RD, Color.WHITE, Color.BLACK);
                }
            }
            case 2 -> {
                g.setColor(new Color(6, 8, 20)); g.fillRect(136, FLOOR + 6, 90, 14);
                g.setColor(new Color(44, 54, 92));
                for (int i = 0; i < 6; i++) g.fillRect(140 + i * 15, FLOOR + 8, 9, 10);
                if (crouchT > 30 || w.f("glyph_seen")) {
                    int a = w.f("glyph_seen") ? 235 : Math.min(190, (crouchT - 30) * 3);
                    g.setColor(A(GR, a));
                    g.fillRect(150, FLOOR + 10, 3, 6); g.fillRect(150, FLOOR + 13, 8, 3);
                    g.fillRect(170, FLOOR + 10, 8, 3); g.fillRect(170, FLOOR + 16, 8, 3);
                    g.fillRect(170, FLOOR + 10, 3, 9); g.fillRect(175, FLOOR + 10, 3, 9);
                }

                boolean wallSolved = puz.done("p_wall");
                pxFrame(g, 452, 232, 200, 118, new Color(20, 16, 48), wallSolved ? GR : MG);
                g.setFont(MONOB);
                g.setColor(wallSolved ? GR : MG);
                String[] gw = (wallSolved ? WALL_PLAIN : WALL_ENC).split(" ");
                int gy = 255; String ln = "";
                for (String s : gw) { if ((ln + s).length() > 16) { g.drawString(ln, 464, gy); gy += 19; ln = ""; } ln += s + " "; }
                g.drawString(ln, 464, gy);
                g.setFont(SMALL); g.setColor(CY);
                g.drawString(wallSolved ? "[DECODED]" : "rot+3 [E]", 582, 342);

                boolean nodeUnlocked = w.f("panel_open");
                drawConduitPulse(g, 770, FLOOR - 155, 1595, FLOOR - 155, CY, w.i("seen") == 15);
                drawConduitPulse(g, 1595, FLOOR - 125, 1750, FLOOR - 135, GR, nodeUnlocked);
            }
            case 3 -> {
                boolean powered = puz.done("p3_power");
                for (int r = 0; r < 6; r++) {
                    int rx0 = 220 + r * 320;
                    pxRect(g, rx0, FLOOR - 230, 110, 230, BLDG_DARK, A(powered ? GR : AM, 140), Color.BLACK);
                    g.setFont(SMALL); g.setColor(powered ? GR : AM);
                    g.drawString("RACK-0" + (r + 1), rx0 + 26, FLOOR - 210);
                    for (int led = 0; led < 5; led++) {
                        g.setColor(powered ? GR : ((r == 1 && led == 2) ? RD : AM));
                        g.fillRect(rx0 + 16 + led * 16, FLOOR - 195, 8, 4);
                    }
                }
                drawConduitPulse(g, 360, 155, 2130, 155, powered ? GR : RD, powered);
                drawConduitPulse(g, 2130, 155, 2130, FLOOR - 190, powered ? GR : RD, powered);
            }
            case 4 -> {
                boolean synced = puz.done("p4_phase");
                int beamY = 235;
                for (int wx = 275; wx < 1980; wx += 8) {
                    double freq = synced ? 0.08 : 0.17;
                    int y1 = snap(Math.sin((wx + tick * 3) * freq) * (synced ? 12 : 24));
                    g.setColor(A(synced ? GR : VI, 195));
                    g.fillRect(wx, beamY + y1, 6, 2 * PX);
                }
                drawHoloSign(g, 230, 210, synced ? "432 Hz [LOCKED]" : vpFreq + " Hz [DRIFT]", synced ? GR : MG);
            }
            case 5 -> {
                boolean unlocked = puz.done("p5_archive");
                for (int r = 0; r < 3; r++) {
                    int rad = snap(26 + r * 14 + Math.sin(tick * 0.05 + r) * 3);
                    g.setColor(A(unlocked ? GR : CY, 145));
                    g.drawRect(390 - rad, 260 - rad / 2, rad * 2, rad);
                }
                drawConduitPulse(g, 390, 260, 1255, 260, unlocked ? GR : CY, unlocked);
                if (unlocked) drawConduitPulse(g, 1255, 260, 1255, 360, GR, true);
            }
            case 6 -> {
                double pulse = 1.0 + 0.08 * Math.sin(tick / 12.0);
                glow(g, 970, 320, (float) (180 * pulse), GR, 105);
                int r1 = snap(80 * pulse), r2 = snap(50 / pulse);
                g.setColor(A(CY, 175));
                g.drawRect(970 - r1, 320 - r1, r1 * 2, r1 * 2);
                g.setColor(A(GR, 200));
                g.drawRect(970 - r2, 320 - r2, r2 * 2, r2 * 2);
                drawConduitPulse(g, 500, 440, 910, 440, GR, true);
            }
        }
    }

    void drawHoloSign(Graphics2D g, int x, int y, String text, Color c) {
        g.setFont(MONOB);
        int tw = g.getFontMetrics().stringWidth(text);
        pxFrame(g, x - 10, y - 18, tw + 20, 26, new Color(20, 16, 54, 225), c);
        drawPixelText(g, text, x, y, c, Color.BLACK);
    }

    void drawObject(Graphics2D g, Obj b) {
        int x = b.x, wd = b.w, fl = b.floor;
        switch (b.kind) {
            case "TERMINAL" -> {
                pxRect(g, x - 10, fl - 38, wd + 20, 38, BLDG_BLUE, CY, BLDG_DARK);
                monitor(g, x + 6, fl - 104, wd - 12, 58, chapterAccent(), true, List.of(b.name, "> ONLINE"));
            }
            case "VENDING" -> {
                // Retro red/coral cyberpunk vending machine inspired by image 2!
                pxRect(g, x, fl - 152, wd, 152, new Color(210, 48, 64), new Color(255, 115, 125), new Color(105, 20, 32));
                pxRect(g, x + 10, fl - 140, wd - 20, 62, new Color(14, 22, 46), CY, null);
                int step = (tick % 200) / 40, lit = (step < 4 && !w.f("purged")) ? SEQ[step] : -1;
                for (int i = 0; i < 4; i++) {
                    int bx = x + 16 + (i % 2) * 36, by = fl - 70 + (i / 2) * 32;
                    boolean on = i == lit && !(tick % 23 == 0);
                    pxRect(g, bx, by, 26, 26, on ? SYMCOL[i] : new Color(24, 26, 48), on ? Color.WHITE : SYMCOL[i], Color.BLACK);
                    sym(g, i, bx + 13, by + 13, 6, on ? Color.WHITE : A(SYMCOL[i], 95));
                }
            }
            case "POSTER", "BOARD" -> {
                pxRect(g, x, fl - 205, wd, 98, b.kind.equals("BOARD") ? new Color(24, 38, 68) : new Color(116, 104, 88),
                        puz.done("p1_hatch") && b.id.equals("c1_board") ? GR : CY, Color.BLACK);
                if (b.id.equals("poster")) {
                    for (int i = 0; i < 4; i++) {
                        sym(g, i, x + 16, fl - 180 + i * 17, 4, new Color(36, 28, 22));
                        g.setFont(SMALL); g.setColor(new Color(36, 28, 22));
                        g.drawString("= " + HEX[i], x + 28, fl - 176 + i * 17);
                    }
                } else if (b.id.equals("c1_board")) {
                    int wx = x + wd - 46, wy = fl - 176;
                    g.setColor(CY); g.drawRect(wx, wy, 36, 36);
                    g.setColor(MG); g.drawRect(wx + 8, wy + 8, 20, 20);
                    double ang = tick * 0.04;
                    g.drawLine(wx + 18, wy + 18, (int) (wx + 18 + Math.cos(ang) * 16), (int) (wy + 18 + Math.sin(ang) * 16));
                    g.setFont(SMALL); g.setColor(CY);
                    g.drawString(puz.done("p1_hatch") ? "DECODED" : "CIPHER [E]", x + 10, fl - 154);
                }
            }
            case "KEYPAD" -> {
                pxRect(g, x + 12, fl - 125, 50, 74, BLDG_DARK, CY, Color.BLACK);
                for (int i = 0; i < 4; i++) {
                    sym(g, SEQ[i], x + 26 + (i % 2) * 20, fl - 104 + (i / 2) * 24, 5, SYMCOL[SEQ[i]]);
                }
            }
            case "CIRCUIT" -> {
                pxRect(g, x, fl - 140, wd, 140, new Color(28, 24, 48), puz.done("p3_power") ? GR : AM, Color.BLACK);
                g.fillRect(x + 16, fl - 100, wd - 32, 2 * PX);
                g.fillRect(x + 16, fl - 60, wd - 32, 2 * PX);
                g.setColor(puz.done("p3_power") ? GR : RD);
                g.fillRect(x + wd / 2 - 8, fl - 88, 16, 16);
            }
            case "WAVE" -> {
                pxRect(g, x, fl - 150, wd, 90, new Color(32, 18, 62), puz.done("p4_phase") ? GR : VI, Color.BLACK);
                for (int wx = 6; wx < wd - 8; wx += 4) {
                    int wy = snap(Math.sin((wx + tick * 3) * 0.14) * 14);
                    g.setColor(puz.done("p4_phase") ? GR : MG);
                    g.fillRect(x + wx, fl - 105 + wy, 2 * PX, 2 * PX);
                }
            }
            case "MONOLITH" -> {
                pxRect(g, x + 10, fl - 190, wd - 20, 190, BLDG_DARK, puz.done("p5_archive") ? GR : CY, Color.BLACK);
                for (int r = 0; r < 3; r++) g.drawRect(x + 24, fl - 155 + r * 38, wd - 48, 24);
            }
            case "CORE" -> {
                pxRect(g, x + 16, fl - 120, wd - 32, 120, new Color(14, 34, 42), GR, Color.BLACK);
                g.setFont(MONOB); g.setColor(GR);
                g.drawString("1969", x + 38, fl - 70);
            }
            case "NPC" -> drawNpc(g, x + wd / 2.0, fl, b.id.equals("c4_echo") ? VI : MG);
            case "DOOR" -> {
                pxRect(g, x, fl - 188, wd, 188, BLDG_DARK, chapterAccent(), Color.BLACK);
                g.setFont(SMALL); g.setColor(chapterAccent());
                g.drawString(b.name.substring(0, Math.min(12, b.name.length())), x + 8, fl - 168);
            }
            case "PANEL" -> {
                pxRect(g, x, fl - 130, wd, 130, BLDG_DARK, GR, Color.BLACK);
                g.setColor(A(GR, 220)); g.fillRect(x + 12, fl - 110, wd - 24, 36);
            }
            case "GRATE" -> {
                g.setColor(GR);
                g.drawRect(x, fl - 24, wd, 24);
            }
        }
    }

    void monitor(Graphics2D g, int x, int y, int wd, int ht, Color c, boolean on, List<String> lines) {
        pxRect(g, x - 6, y - 6, wd + 12, ht + 14, BLDG_BLUE, CY, BLDG_DARK);
        boolean fl = rnd.nextInt(32) == 0;
        g.setColor(on ? A(c, fl ? 85 : 175) : new Color(8, 10, 14));
        g.fillRect(x, y, wd, ht);
        if (on) {
            g.setFont(SMALL); g.setColor(new Color(0, 18, 22, 245));
            for (int i = 0; i < Math.min(lines.size(), 4); i++) {
                String s = lines.get(i);
                g.drawString(s.substring(0, Math.min(s.length(), 13)), x + 4, y + 13 + i * 11);
            }
        }
        g.setColor(BLDG_BLUE); g.fillRect(x + wd / 2 - 8, y + ht + 8, 16, 6);
    }

    void drawNpc(Graphics2D g, double x, double y, Color visorCol) {
        int ix = snap(x), iy = snap(y + Math.sin(tick / 24.0) * 2.0);
        pxRect(g, ix - 18, iy - 68, 36, 56, new Color(36, 18, 62), visorCol, Color.BLACK);
        g.fillRect(ix - 14, (int) y - 12, 10, 12);
        g.fillRect(ix + 4, (int) y - 12, 10, 12);
        pxRect(g, ix - 14, iy - 94, 28, 28, new Color(22, 10, 38), visorCol, Color.BLACK);
        boolean glt = tick % 110 < 5;
        g.setColor(glt ? CY : visorCol);
        g.fillRect(ix - 10 + (glt ? 2 : 0), iy - 84, 20, 10);
        g.setColor(Color.BLACK); g.setFont(SMALL);
        g.drawString(visorCol == VI ? "??" : ":|", ix - 6, iy - 76);
    }

    void drawGirlPlayer(Graphics2D g, double x, double y, int f, boolean cr, boolean moving, float alpha) {
        Composite old = g.getComposite();
        g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));

        int h = cr ? 36 : 58;
        int stride = moving ? snap(Math.sin(tick * 0.32) * 5.0) : 0;
        int bob = moving ? snap(Math.abs(Math.sin(tick * 0.32)) * 2.5) : snap(Math.sin(tick * 0.08) * 1.0);
        int hairSway = moving ? snap(-f * (4.5 + Math.sin(tick * 0.32) * 2.5)) : snap(Math.sin(tick * 0.07) * 2.0);

        int bx = snap(x);
        int by = snap(y - bob);

        Color skin = new Color(255, 224, 206);
        Color blush = new Color(255, 145, 165, 160);
        Color hairDark = new Color(46, 30, 74);
        Color hairHighlight = new Color(125, 82, 190);
        Color jacket = new Color(26, 28, 48);
        Color skirt = new Color(36, 24, 58);

        int headY = by - h;
        g.setColor(hairDark);
        g.fillRect(bx - f * 12 + hairSway / 2, headY + 8, 8, 12);
        g.fillRect(bx - f * 16 + hairSway, headY + 18, 8, 14);

        int legH = cr ? 10 : 20;
        int lx1 = bx - 6 + stride;
        int lx2 = bx + 2 - stride;
        g.setColor(skin);
        g.fillRect(lx1, by - legH, 6, 6);
        g.fillRect(lx2, by - legH, 6, 6);
        g.setColor(new Color(22, 22, 38));
        g.fillRect(lx1, by - legH + 6, 6, legH - 10);
        g.fillRect(lx2, by - legH + 6, 6, legH - 10);
        g.setColor(CY);
        g.fillRect(lx1, by - legH + 6, 6, 2);
        g.fillRect(lx2, by - legH + 6, 6, 2);
        g.setColor(new Color(38, 36, 62));
        g.fillRect(lx1 - 2, by - 6, 8, 6);
        g.fillRect(lx2 - 2, by - 6, 8, 6);
        g.setColor(CY);
        g.fillRect(lx1 - 2, by - 2, 8, 2);
        g.fillRect(lx2 - 2, by - 2, 8, 2);

        int torsoBot = by - legH + 2;
        int torsoTop = headY + 18;
        g.setColor(skirt);
        g.fillRect(bx - 10, torsoBot - 8, 20, 10);
        g.setColor(MG);
        g.fillRect(bx - 10, torsoBot, 20, 2);

        g.setColor(new Color(220, 235, 245));
        g.fillRect(bx - 6, torsoTop, 12, torsoBot - torsoTop - 8);
        g.setColor(jacket);
        g.fillRect(bx - 8, torsoTop, 16, torsoBot - torsoTop - 10);
        g.setColor(CY);
        g.fillRect(bx - 6, torsoTop, 12, 2);
        g.fillRect(bx + f * 4, torsoTop + 4, 2, 6);

        g.setColor(skin);
        g.fillRect(bx - 8, headY + 2, 16, 16);

        int eyeX = f > 0 ? bx + 2 : bx - 6;
        g.setColor(blush);
        g.fillRect(eyeX - 2, headY + 12, 6, 2);
        if (blinkT > 0) {
            g.setColor(hairDark);
            g.fillRect(eyeX, headY + 10, 4, 2);
        } else {
            g.setColor(new Color(28, 34, 62));
            g.fillRect(eyeX, headY + 8, 4, 4);
            g.setColor(CY);
            g.fillRect(eyeX + (f > 0 ? 2 : 0), headY + 8, 2, 2);
        }

        g.setColor(hairDark);
        g.fillRect(bx - 10, headY, 20, 6);
        g.fillRect(bx - 10, headY + 6, 4, 4);
        g.fillRect(bx - 2, headY + 6, 4, 2);
        g.fillRect(bx + 6, headY + 6, 4, 4);

        g.setColor(hairHighlight);
        g.fillRect(bx - f * 10 + hairSway / 2, headY + 6, 6, 12);
        g.fillRect(bx - f * 14 + hairSway, headY + 16, 6, 12);
        g.setColor(MG);
        g.fillRect(bx - f * 6, headY + 6, 4, 2);

        int armX = bx - f * 2;
        g.setColor(jacket);
        g.fillRect(armX - 2, torsoTop + 2, 6, 10);
        g.setColor(skin);
        g.fillRect(armX - 2, torsoTop + 12, 4, 4);
        if (termOpen || visPuzzle != null) {
            g.setColor(GR);
            g.fillRect(armX - 2, torsoTop + 10, 6, 4);
            glow(g, armX + f * 6, torsoTop + 10, 14, GR, 130);
        }

        g.setComposite(old);
    }

    void drawLighting(Graphics2D g, int cx, Color acc) {
        Graphics2D d = dark.createGraphics();
        d.setComposite(AlphaComposite.Src);
        // Lighter twilight atmospheric tint so the rich violet/blue cityscape shines through clearly
        d.setColor(new Color(14, 10, 38, 92));
        d.fillRect(0, 0, W, H);
        d.setComposite(AlphaComposite.DstOut);
        light(d, px - cx, py - 32, 310, 1f);
        for (Obj b : objs) {
            if (b.vis.get()) light(d, b.cx() - cx, b.floor - 60, 180, .85f);
        }
        d.dispose();
        g.drawImage(dark, 0, 0, null);
        glow(g, px - cx, py - 32, 130, acc, 36);
    }

    void light(Graphics2D d, double x, double y, float r, float s) {
        d.setPaint(new RadialGradientPaint((float) x, (float) y, r, new float[]{0f, 1f},
                new Color[]{new Color(0, 0, 0, (int) (255 * Math.min(1f, s))), new Color(0, 0, 0, 0)}));
        d.fillOval((int) (x - r), (int) (y - r), (int) (2 * r), (int) (2 * r));
    }

    // ======================================================== INTERACTIVE CLICKABLE VISUAL PUZZLE OVERLAYS
    void drawVisualPuzzle(Graphics2D g) {
        g.setColor(new Color(8, 8, 26, 215));
        g.fillRect(0, 0, W, H);
        int pw = 760, ph = 460, px0 = (W - pw) / 2, py0 = (H - ph) / 2;

        switch (visPuzzle) {
            case "ch1_cipher" -> {
                box(g, px0, py0, pw, ph, BL);
                g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 20));
                drawPixelText(g, "VISUAL CIPHER WHEEL // LAB WHITEBOARD", px0 + 28, py0 + 38, CY, Color.BLACK);
                g.setFont(SMALL); g.setColor(TXT_DIM);
                g.drawString("Click buttons or use LEFT/RIGHT + ENTER to rotate & submit", px0 + 28, py0 + 60);

                int cx = px0 + 185, cy = py0 + 235;
                g.setColor(new Color(14, 24, 44)); g.fillOval(cx - 130, cy - 130, 260, 260);
                g.setColor(BL); g.drawOval(cx - 130, cy - 130, 260, 260);
                g.setColor(new Color(20, 36, 62)); g.fillOval(cx - 92, cy - 92, 184, 184);
                g.setColor(CY); g.drawOval(cx - 92, cy - 92, 184, 184);

                g.setFont(SMALL);
                for (int i = 0; i < 26; i++) {
                    double ang = -Math.PI / 2 + i * (2 * Math.PI / 26.0);
                    char outerCh = (char) ('A' + i);
                    char innerCh = (char) ('A' + (i + vpShift) % 26);
                    g.setColor(i == 0 ? MG : Color.WHITE);
                    g.drawString("" + outerCh, (int) (cx + Math.cos(ang) * 110 - 3), (int) (cy + Math.sin(ang) * 110 + 4));
                    g.setColor(i == 0 ? GR : CY);
                    g.drawString("" + innerCh, (int) (cx + Math.cos(ang) * 74 - 3), (int) (cy + Math.sin(ang) * 74 + 4));
                }
                g.setFont(MONOB); g.setColor(AM);
                g.drawString("SHIFT: -" + vpShift, cx - 36, cy + 5);

                drawBtn(g, cx - 120, py0 + 388, 110, 32, "< SHIFT -1", CY, () -> { vpShift = (vpShift + 25) % 26; tone(720, 18, .2); }, "Rotate inner cipher ring backward");
                drawBtn(g, cx + 10, py0 + 388, 110, 32, "SHIFT +1 >", CY, () -> { vpShift = (vpShift + 1) % 26; tone(780, 18, .2); }, "Rotate inner cipher ring forward");

                int rx = px0 + 365, ry = py0 + 105, rw = 365;
                box(g, rx, ry, rw, 250, A(CY, 160));
                g.setFont(SMALL); g.setColor(MG); g.drawString("ENCODED CHALK:", rx + 16, ry + 28);
                g.setFont(MONO); g.setColor(Color.WHITE);
                int yy = ry + 50;
                for (String ln : wrap(LAB_ENC, g.getFontMetrics(), rw - 32)) { g.drawString(ln, rx + 16, yy); yy += 18; }
                g.setFont(SMALL); g.setColor(GR); g.drawString("LIVE WHEEL OUTPUT:", rx + 16, ry + 125);
                g.setFont(MONOB); g.setColor(GR);
                yy = ry + 148;
                for (String ln : wrap(caesar(LAB_ENC, -vpShift), g.getFontMetrics(), rw - 32)) { g.drawString(ln, rx + 16, yy); yy += 20; }

                drawBtn(g, rx, py0 + 388, 220, 32, "SUBMIT DECODED [ENTER]", GR, this::submitVisualPuzzle, "Submit current decoded phrase");
                drawBtn(g, rx + 235, py0 + 388, 130, 32, "CLOSE [ESC]", MG, () -> visPuzzle = null, "Close puzzle overlay");
            }

            case "ch2_wall" -> {
                box(g, px0, py0, pw, ph, MG);
                g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 20));
                drawPixelText(g, "NEON PRISM DECODER // CAFE GRAFFITI (ROT+3)", px0 + 28, py0 + 38, MG, Color.BLACK);
                g.setFont(SMALL); g.setColor(TXT_DIM);
                g.drawString("Click buttons or use LEFT/RIGHT + ENTER to slide spectral offset", px0 + 28, py0 + 60);

                int sx = px0 + 40, sy = py0 + 90, sw = 680;
                pxFrame(g, sx, sy, sw, 82, new Color(12, 16, 30), CY);
                g.setFont(MONO);
                for (int i = 0; i < 26; i++) {
                    int lx = sx + 14 + i * 25;
                    g.setColor(i == 0 ? MG : Color.WHITE);
                    g.drawString("" + (char) ('A' + i), lx, sy + 28);
                    g.setColor(i == 0 ? GR : CY);
                    g.drawString("" + (char) ('A' + (i + vpWallShift) % 26), lx, sy + 64);
                }
                g.setFont(MONOB); g.setColor(AM);
                g.drawString("SPECTRAL OFFSET: -" + vpWallShift, px0 + 45, py0 + 200);

                box(g, px0 + 40, py0 + 218, 680, 155, A(MG, 180));
                g.setFont(SMALL); g.setColor(MG); g.drawString("NEON BRICK CIPHERTEXT:", px0 + 58, py0 + 244);
                g.setFont(MONO); g.setColor(Color.WHITE); g.drawString(WALL_ENC, px0 + 58, py0 + 268);
                g.setFont(SMALL); g.setColor(GR); g.drawString("DECODED GRAFFITI STREAM:", px0 + 58, py0 + 310);
                g.setFont(MONOB); g.setColor(GR); g.drawString(caesar(WALL_ENC, -vpWallShift), px0 + 58, py0 + 336);

                drawBtn(g, px0 + 40, py0 + 395, 130, 32, "< OFFSET -1", CY, () -> { vpWallShift = (vpWallShift + 25) % 26; tone(760, 18, .2); }, "Decrease ROT shift");
                drawBtn(g, px0 + 185, py0 + 395, 130, 32, "OFFSET +1 >", CY, () -> { vpWallShift = (vpWallShift + 1) % 26; tone(820, 18, .2); }, "Increase ROT shift");
                drawBtn(g, px0 + 365, py0 + 395, 210, 32, "LOCK TRANSLATION [ENTER]", GR, this::submitVisualPuzzle, "Submit decoded graffiti");
                drawBtn(g, px0 + 590, py0 + 395, 130, 32, "CLOSE [ESC]", MG, () -> visPuzzle = null, "Close overlay");
            }

            case "ch2_keypad" -> {
                box(g, px0, py0, pw, ph, MG);
                g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 20));
                drawPixelText(g, "HEX SYMBOL KEYPAD // NODE 0x01 HANDSHAKE", px0 + 28, py0 + 38, MG, Color.BLACK);
                g.setFont(SMALL); g.setColor(TXT_DIM);
                g.drawString("Click ▲ / ▼ or slots to set hex digits (0-F), then click UNLOCK", px0 + 28, py0 + 60);

                g.setFont(MONO); g.setColor(CY);
                g.drawString("POSTER KEY:", px0 + 45, py0 + 98);
                for (int i = 0; i < 4; i++) {
                    int lx = px0 + 165 + i * 135;
                    sym(g, i, lx, py0 + 93, 8, SYMCOL[i]);
                    g.setColor(Color.WHITE);
                    g.drawString("= " + HEX[i], lx + 16, py0 + 98);
                }

                for (int i = 0; i < 4; i++) {
                    final int idx = i;
                    int cx = px0 + 75 + i * 160, cy = py0 + 125, cw = 130, ch = 240;
                    boolean sel = i == vpCursor;
                    pxFrame(g, cx, cy, cw, ch, sel ? new Color(24, 34, 58) : new Color(12, 16, 28), sel ? Color.WHITE : SYMCOL[SEQ[i]]);
                    regHit(cx, cy, cw, ch, () -> vpCursor = idx, "Select hex slot #" + (idx + 1));

                    g.setFont(SMALL); g.setColor(TXT_DIM);
                    g.drawString("BLINK #" + (i + 1), cx + 38, cy + 22);
                    sym(g, SEQ[i], cx + cw / 2.0, cy + 62, 20, SYMCOL[SEQ[i]]);

                    drawBtn(g, cx + 25, cy + 94, 80, 26, "▲ (+1)", CY, () -> {
                        vpCursor = idx; vpKeyDigits[idx] = (vpKeyDigits[idx] + 1) % 16; tone(900, 18, .2);
                    }, "Increment hex digit");

                    g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 42));
                    g.setColor(sel ? GR : Color.WHITE);
                    String hexChar = Integer.toHexString(vpKeyDigits[i]).toUpperCase();
                    g.drawString(hexChar, cx + cw / 2 - 13, cy + 168);

                    drawBtn(g, cx + 25, cy + 186, 80, 26, "▼ (-1)", CY, () -> {
                        vpCursor = idx; vpKeyDigits[idx] = (vpKeyDigits[idx] + 15) % 16; tone(840, 18, .2);
                    }, "Decrement hex digit");
                }

                drawBtn(g, px0 + 180, py0 + 395, 230, 34, "UNLOCK NODE 0x01 [ENTER]", GR, this::submitVisualPuzzle, "Submit 4-digit hex code");
                drawBtn(g, px0 + 430, py0 + 395, 140, 34, "CLOSE [ESC]", MG, () -> visPuzzle = null, "Close keypad");
            }

            case "ch3_circuit" -> {
                box(g, px0, py0, pw, ph, AM);
                g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 20));
                drawPixelText(g, "SUBSTATION POWER MATRIX // AUX-3 -> GATE-9", px0 + 28, py0 + 38, AM, Color.BLACK);
                g.setFont(SMALL); g.setColor(TXT_DIM);
                g.drawString("Click any relay box to toggle OPEN/CLOSED, then click ENERGIZE GRID", px0 + 28, py0 + 60);

                pxRect(g, px0 + 35, py0 + 205, 95, 50, GR, Color.WHITE, Color.BLACK);
                g.setColor(Color.BLACK); g.setFont(MONOB); g.drawString("AUX-3 IN", px0 + 46, py0 + 235);

                boolean energized = vpNodes[0] && !vpNodes[1] && vpNodes[2] && vpNodes[3] && vpNodes[5];
                pxRect(g, px0 + 630, py0 + 205, 95, 50, energized ? GR : RD, Color.WHITE, Color.BLACK);
                g.setColor(Color.BLACK); g.drawString("GATE-9", px0 + 650, py0 + 235);

                int[][] nPos = {{210, 155}, {365, 155}, {520, 155}, {210, 305}, {365, 305}, {520, 305}};
                String[] nLabels = {"RELAY-1", "BREAKER-B [SHORT]", "RELAY-3", "RELAY-4", "SHUNT-5", "RELAY-6"};

                g.setStroke(new BasicStroke(4f));
                g.setColor(vpNodes[0] ? GR : new Color(60, 65, 80));
                g.drawLine(px0 + 130, py0 + 230, px0 + nPos[0][0], py0 + nPos[0][1]);
                g.drawLine(px0 + nPos[0][0], py0 + nPos[0][1], px0 + nPos[3][0], py0 + nPos[3][1]);
                g.setColor(vpNodes[3] ? GR : new Color(60, 65, 80));
                g.drawLine(px0 + nPos[3][0], py0 + nPos[3][1], px0 + nPos[2][0], py0 + nPos[2][1]);
                g.setColor(vpNodes[2] && vpNodes[5] ? GR : new Color(60, 65, 80));
                g.drawLine(px0 + nPos[2][0], py0 + nPos[2][1], px0 + nPos[5][0], py0 + nPos[5][1]);
                g.drawLine(px0 + nPos[5][0], py0 + nPos[5][1], px0 + 630, py0 + 230);

                for (int i = 0; i < 6; i++) {
                    final int idx = i;
                    int nx = px0 + nPos[i][0], ny = py0 + nPos[i][1];
                    boolean sel = i == vpCursor;
                    Color nodeCol = (i == 1) ? RD : (vpNodes[i] ? GR : new Color(95, 108, 130));
                    pxFrame(g, nx - 54, ny - 34, 108, 68, new Color(14, 18, 28), sel ? Color.WHITE : nodeCol);
                    regHit(nx - 54, ny - 34, 108, 68, () -> {
                        vpCursor = idx;
                        vpNodes[idx] = !vpNodes[idx];
                        tone(vpNodes[idx] ? 1050 : 520, 22, .25);
                    }, "Click to toggle " + nLabels[idx]);

                    g.setFont(SMALL); g.setColor(nodeCol);
                    g.drawString(nLabels[i], nx - 46, ny - 10);
                    g.setFont(MONOB);
                    g.drawString(vpNodes[i] ? "[ CLOSED ]" : "[  OPEN  ]", nx - 42, ny + 16);
                }

                drawBtn(g, px0 + 180, py0 + 395, 230, 34, "ENERGIZE GRID [ENTER]", GR, this::submitVisualPuzzle, "Test circuit route to GATE-9");
                drawBtn(g, px0 + 430, py0 + 395, 140, 34, "CLOSE [ESC]", MG, () -> visPuzzle = null, "Close matrix");
            }

            case "ch4_wave" -> {
                box(g, px0, py0, pw, ph, VI);
                g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 20));
                drawPixelText(g, "GHOST NETWORK // CARRIER WAVE OSCILLOSCOPE", px0 + 28, py0 + 38, VI, Color.BLACK);
                g.setFont(SMALL); g.setColor(TXT_DIM);
                g.drawString("Click frequency buttons or use LEFT/RIGHT to match the 432 Hz cyan carrier", px0 + 28, py0 + 60);

                int sx = px0 + 50, sy = py0 + 90, sw = 660, sh = 225;
                pxFrame(g, sx, sy, sw, sh, new Color(6, 10, 18), CY);
                g.setColor(A(CY, 40));
                for (int gx = sx; gx <= sx + sw; gx += 30) g.drawLine(gx, sy, gx, sy + sh);
                for (int gy = sy; gy <= sy + sh; gy += 30) g.drawLine(sx, gy, sx + sw, gy);

                int midY = sy + sh / 2;
                for (int x = 0; x < sw - 4; x += 4) {
                    int yTarget = snap(Math.sin((x + tick * 2) * (432 / 4000.0)) * 75);
                    g.setColor(A(CY, 190));
                    g.fillRect(sx + x, midY + yTarget, 4, 2 * PX);

                    int yUser = snap(Math.sin((x + tick * 2) * (vpFreq / 4000.0)) * 75);
                    g.setColor(vpFreq == 432 ? GR : MG);
                    g.fillRect(sx + x, midY + yUser, 4, 2 * PX);
                }

                g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 22));
                g.setColor(vpFreq == 432 ? GR : Color.WHITE);
                g.drawString("TUNER FREQUENCY: " + vpFreq + " Hz" + (vpFreq == 432 ? "  [HARMONIC LOCK]" : ""), px0 + 50, py0 + 355);

                drawBtn(g, px0 + 50, py0 + 392, 130, 34, "< -4 Hz", CY, () -> { vpFreq = Math.max(360, vpFreq - 4); tone(vpFreq, 18, .2); }, "Lower frequency by 4 Hz");
                drawBtn(g, px0 + 195, py0 + 392, 130, 34, "+4 Hz >", CY, () -> { vpFreq = Math.min(480, vpFreq + 4); tone(vpFreq, 18, .2); }, "Raise frequency by 4 Hz");
                drawBtn(g, px0 + 365, py0 + 392, 200, 34, "LOCK PHASE [ENTER]", GR, this::submitVisualPuzzle, "Lock carrier wave");
                drawBtn(g, px0 + 580, py0 + 392, 130, 34, "CLOSE [ESC]", MG, () -> visPuzzle = null, "Close oscilloscope");
            }

            case "ch5_rings" -> {
                box(g, px0, py0, pw, ph, CY);
                g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 20));
                drawPixelText(g, "GENESIS MONOLITH // 1969 ARCHITECT TUMBLERS", px0 + 28, py0 + 38, CY, Color.BLACK);
                g.setFont(SMALL); g.setColor(TXT_DIM);
                g.drawString("Click ▲ / ▼ on each tumbler ring to set the archive key, then click DECRYPT", px0 + 28, py0 + 60);

                for (int i = 0; i < 6; i++) {
                    final int idx = i;
                    int rx = px0 + 65 + i * 108 + (i >= 4 ? 24 : 0), ry = py0 + 115, rw = 86, rh = 240;
                    boolean sel = i == vpCursor;
                    pxFrame(g, rx, ry, rw, rh, sel ? new Color(18, 36, 54) : new Color(10, 16, 26), sel ? GR : CY);
                    regHit(rx, ry, rw, rh, () -> vpCursor = idx, "Select tumbler #" + (idx + 1));

                    drawBtn(g, rx + 13, ry + 14, 60, 28, "▲ (+1)", CY, () -> {
                        vpCursor = idx; vpRings[idx] = (vpRings[idx] + 1) % 10; tone(860, 18, .2);
                    }, "Rotate tumbler up");

                    g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 44));
                    g.setColor(sel ? Color.WHITE : CY);
                    g.drawString("" + vpRings[i], rx + 29, ry + 134);

                    drawBtn(g, rx + 13, ry + 194, 60, 28, "▼ (-1)", CY, () -> {
                        vpCursor = idx; vpRings[idx] = (vpRings[idx] + 9) % 10; tone(800, 18, .2);
                    }, "Rotate tumbler down");
                }
                g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 34)); g.setColor(CY);
                g.drawString("-", px0 + 498, py0 + 245);

                drawBtn(g, px0 + 180, py0 + 395, 230, 34, "DECRYPT VAULT [ENTER]", GR, this::submitVisualPuzzle, "Submit 6-digit monolith key");
                drawBtn(g, px0 + 430, py0 + 395, 140, 34, "CLOSE [ESC]", MG, () -> visPuzzle = null, "Close monolith");
            }

            case "ch6_core" -> {
                box(g, px0, py0, pw, ph, GR);
                g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 20));
                drawPixelText(g, "SOCKET 0x00 // 1969 ROOT HANDSHAKE CONSOLE", px0 + 28, py0 + 38, GR, Color.BLACK);
                g.setFont(SMALL); g.setColor(TXT_DIM);
                g.drawString("Dial the final 3 letters & click TRANSMIT (True Ending), or click an alternate protocol", px0 + 28, py0 + 60);

                char[] fixed = {'L', 'O'};
                for (int i = 0; i < 2; i++) {
                    int lx = px0 + 110 + i * 110, ly = py0 + 100;
                    pxFrame(g, lx, ly, 90, 155, new Color(14, 34, 30), GR);
                    g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 52)); g.setColor(GR);
                    g.drawString("" + fixed[i], lx + 28, ly + 92);
                    g.setFont(SMALL); g.drawString("1969", lx + 30, ly + 135);
                }
                for (int i = 0; i < 3; i++) {
                    final int idx = i;
                    int lx = px0 + 340 + i * 110, ly = py0 + 100;
                    boolean sel = i == vpCursor;
                    pxFrame(g, lx, ly, 90, 155, sel ? new Color(24, 48, 42) : new Color(12, 20, 28), sel ? Color.WHITE : CY);
                    regHit(lx, ly, 90, 155, () -> vpCursor = idx, "Select letter slot");

                    drawBtn(g, lx + 15, ly + 8, 60, 24, "▲", CY, () -> {
                        vpCursor = idx; vpLetters[idx] = (char) ('A' + (vpLetters[idx] - 'A' + 1) % 26); tone(950, 18, .2);
                    }, "Next letter");

                    g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 48)); g.setColor(sel ? Color.WHITE : CY);
                    g.drawString("" + vpLetters[i], lx + 29, ly + 96);

                    drawBtn(g, lx + 15, ly + 120, 60, 24, "▼", CY, () -> {
                        vpCursor = idx; vpLetters[idx] = (char) ('A' + (vpLetters[idx] - 'A' + 25) % 26); tone(890, 18, .2);
                    }, "Previous letter");
                }

                drawBtn(g, px0 + 190, py0 + 272, 250, 34, "TRANSMIT HANDSHAKE [ENTER]", GR, this::submitVisualPuzzle, "Complete 1969 LOGIN handshake");
                drawBtn(g, px0 + 460, py0 + 272, 120, 34, "CLOSE [ESC]", MG, () -> visPuzzle = null, "Step back from Root Core");

                int by = py0 + 322;
                drawBtn(g, px0 + 50, by, 315, 32, "[1] DISCONNECT (Escape to Surface)", CY, () -> triggerEnding(0), "Trigger Ending 1");
                drawBtn(g, px0 + 390, by, 315, 32, "[2] NEW ADMIN (Seize Root Control)", AM, () -> triggerEnding(1), "Trigger Ending 2");
                drawBtn(g, px0 + 50, by + 42, 315, 32, "[3] THE LOOP (Retransmit 03:12 AM)", MG, () -> triggerEnding(2), "Trigger Ending 3");
                if (w.f("mirrored") && clues.has("c4_ghost_id")) {
                    drawBtn(g, px0 + 390, by + 42, 315, 32, "[4] GHOST USER (Merge visitor_0)", VI, () -> triggerEnding(3), "Trigger Ending 4");
                }
            }
        }
    }

    // ---------------------------------------------------------------- HUD
    String objective() {
        return switch (chapter) {
            case 1 -> puz.done("p1_hatch") ? "Descend through the eastern floor hatch." : "Click or press [E] on the Whiteboard Cipher Wheel.";
            case 2 -> w.f("node_active") ? "Enter a verdict at Node 0x01 or head east." : "Decode the Graffiti [E] & unlock the Hex Keypad [E].";
            case 3 -> puz.done("p3_power") ? "Enter Bulkhead Gate-9 to the east." : "Solve the Substation Power Matrix [E].";
            case 4 -> puz.done("p4_phase") ? "Step through the stabilized Rift." : "Tune the Carrier Wave Oscilloscope [E] to 432 Hz.";
            case 5 -> puz.done("p5_archive") ? "Read imp_1969's vault & descend below." : "Align the Genesis Monolith Tumblers [E] (1969-01).";
            default -> "Click or press [E] on THE ROOT CORE socket.";
        };
    }

    void drawHud(Graphics2D g) {
        Color acc = chapterAccent();
        box(g, 14, 12, 435, 76, acc);
        g.setFont(MONOB);
        drawPixelText(g, CH_NAMES[chapter], 26, 32, acc, Color.BLACK);
        g.setFont(MONO); g.setColor(CY);
        g.drawString("CLUES: " + clues.found().size() + "/" + clues.defs.size() + "   TRUST: " + w.i("trust"), 26, 52);
        g.setColor(TXT_MAIN);
        g.drawString("> " + objective(), 26, 73);

        if (roLines == null && visPuzzle == null && dlg.cur == null && !journal && !mapOpen) {
            int bx = W - 495, by = H - 38;
            drawBtn(g, bx, by, 125, 26, termOpen ? "CLOSE DECK [TAB]" : "CYBERDECK [TAB]", GR, () -> { termOpen = !termOpen; left = right = up = down = false; }, "Toggle Cyberdeck Terminal");
            drawBtn(g, bx + 132, by, 110, 26, "JOURNAL [J]", CY, () -> { journal = !journal; left = right = up = down = false; }, "Open Clue Conspiracy Board");
            drawBtn(g, bx + 249, by, 90, 26, "MAP [M]", VI, () -> { mapOpen = !mapOpen; left = right = up = down = false; }, "View Network Topology Map");
            drawBtn(g, bx + 346, by, 72, 26, "SAVE", AM, () -> { save(slot); toast("SESSION SAVED (Slot " + (slot + 1) + ")"); }, "Save Progress (F5)");
            drawBtn(g, bx + 424, by, 58, 26, "MENU", MG, () -> { save(slot); state = MENU; }, "Save & Return to Main Menu");
        }

        Obj n = (roLines == null && visPuzzle == null && dlg.cur == null && !termOpen && !journal && !mapOpen) ? nearest(58) : null;
        if (n != null) {
            int sx = snap(n.cx() - camX);
            int sy = (int) (n.floor - 135);
            g.setFont(MONOB);
            String t = "[E / CLICK] " + n.name;
            int tw = g.getFontMetrics().stringWidth(t);
            box(g, sx - tw / 2 - 8, sy - 18, tw + 16, 26, CY);
            drawPixelText(g, t, sx - tw / 2, sy, Color.WHITE, Color.BLACK);
            regHit(sx - tw / 2 - 8, sy - 18, tw + 16, 26, () -> { n.use.run(); tone(440, 35, .28); }, "Interact with " + n.name);
            if (n.term) {
                g.setFont(SMALL);
                g.setColor(A(GR, 175 + (int) (75 * Math.sin(tick / 8.0))));
                g.drawString("[TAB] cyberdeck supported", sx - 64, sy + 22);
            }
        }

        g.setFont(MONO); int y = 106;
        for (Toast t : toasts) {
            int a = Math.min(255, t.life * 4);
            int tw = g.getFontMetrics().stringWidth(t.t);
            pxFrame(g, 14, y - 15, tw + 22, 24, new Color(12, 16, 38, Math.min(230, a)), A(GR, a));
            g.setColor(A(GR, a));
            g.drawString(t.t, 24, y);
            y += 28;
        }

        g.setFont(SMALL); g.setColor(TXT_DIM);
        g.drawString("Click objects/floor or A/D Move | W Jump | S Crouch | E Interact | TAB Deck | J Journal | M Map", 16, H - 14);

        int bx = 460, bw = W - 14 - bx, by = 12;
        if (roLines != null) {
            g.setFont(MONO); FontMetrics fm = g.getFontMetrics(); List<String> all = new ArrayList<>();
            for (String s : roLines) all.addAll(wrap(s, fm, bw - 36));
            int h = 68 + all.size() * 19;
            box(g, bx, by, bw, h, CY);
            g.setFont(MONOB); drawPixelText(g, roTitle, bx + 18, by + 24, MG, Color.BLACK);
            g.setFont(MONO); g.setColor(TXT_MAIN);
            int yy = by + 48;
            for (String s : all) { g.drawString(s, bx + 18, yy); yy += 19; }
            drawBtn(g, bx + bw - 145, by + h - 32, 130, 24, "CONTINUE [E]", CY, () -> roLines = null, "Dismiss message");
        }
        if (dlg.cur != null) {
            g.setFont(MONO); FontMetrics fm = g.getFontMetrics();
            List<String> all = wrap(dlg.cur.text, fm, bw - 36);
            List<DChoice> v = dlg.visible();
            int h = 72 + all.size() * 19 + Math.max(1, v.size()) * 28;
            box(g, bx, by, bw, h, MG);
            g.setFont(MONOB); drawPixelText(g, dlg.cur.speaker, bx + 18, by + 24, MG, Color.BLACK);
            g.setFont(MONO); g.setColor(TXT_MAIN);
            int yy = by + 48;
            for (String s : all) { g.drawString(s, bx + 18, yy); yy += 19; }
            yy += 8;
            if (v.isEmpty()) {
                drawBtn(g, bx + 18, yy - 6, 140, 24, "END CHAT [E]", CY, () -> dlg.cur = null, "End conversation");
            } else {
                for (int i = 0; i < v.size(); i++) {
                    final int idx = i;
                    drawBtn(g, bx + 18, yy - 4, bw - 36, 24, (i + 1) + ") " + v.get(i).label, CY, () -> dlg.pick(idx), "Click to choose dialogue option");
                    yy += 28;
                }
            }
        }
    }

    // ---------------------------------------------------------------- Network Map Overlay [M]
    void drawWorldMap(Graphics2D g) {
        g.setColor(new Color(10, 12, 34, 242));
        g.fillRect(0, 0, W, H);
        g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 22));
        drawPixelText(g, "UNDERGROUND INTERNET // TOPOLOGY MAP", 40, 48, CY, Color.BLACK);
        g.setFont(SMALL); g.setColor(TXT_DIM);
        g.drawString("Click an unlocked node to fast-travel, or click CLOSE [M]", 40, 68);
        drawBtn(g, W - 150, 30, 110, 30, "CLOSE [M]", MG, () -> mapOpen = false, "Close topology map");

        int maxCh = Math.max(1, w.i("max_chapter"));
        int[][] coords = {{0,0}, {160, 220}, {340, 340}, {540, 220}, {740, 360}, {920, 230}, {1020, 440}};
        g.setStroke(new BasicStroke(3f));
        for (int i = 1; i < 6; i++) {
            g.setColor(i < maxCh ? GR : new Color(60, 70, 90));
            g.drawLine(coords[i][0], coords[i][1], coords[i + 1][0], coords[i + 1][1]);
        }
        for (int i = 1; i <= 6; i++) {
            final int targetCh = i;
            boolean unlocked = i <= maxCh;
            boolean current = i == chapter;
            int nx = coords[i][0], ny = coords[i][1];
            if (current) glow(g, nx, ny, 45, CY, 130);
            pxFrame(g, nx - 24, ny - 24, 48, 48, unlocked ? BLDG_DARK : new Color(18, 16, 36), current ? Color.WHITE : unlocked ? CY : MG);
            g.setFont(MONOB); g.setColor(current ? Color.WHITE : unlocked ? CY : MG);
            g.drawString("0" + i, nx - 9, ny + 5);
            g.setFont(SMALL);
            g.drawString(unlocked ? CH_NAMES[i] : "NODE 0" + i + " [LOCKED]", nx - 65, ny + 42);
            if (unlocked && !current) {
                regHit(nx - 30, ny - 30, 60, 60, () -> {
                    mapOpen = false;
                    buildChapter(targetCh, 140);
                    toast("Fast-traveled to " + CH_NAMES[targetCh]);
                }, "Click to fast-travel to " + CH_NAMES[i]);
            }
        }
    }

    // ---------------------------------------------------------------- SCROLLABLE CYBERDECK TERMINAL [TAB]
    void drawTerminal(Graphics2D g) {
        if (termAnim < 0.01) return;
        int x = snap(W - termAnim * TW), y = 24, wd = TW, ht = H - 64;

        pxFrame(g, x, y, wd, ht, new Color(10, 14, 34, 250), CY);
        pxRect(g, x + PX, y + PX, wd - 2 * PX, 28, BLDG_BLUE, CY, BLDG_DARK);
        g.setFont(MONOB);
        drawPixelText(g, "MH-DECK // visitor_0@node0" + chapter, x + 12, y + 20, GR, Color.BLACK);

        if (termOpen && termAnim > 0.9) {
            drawBtn(g, x + wd - 72, y + 4, 64, 22, "X [ESC]", MG, () -> termOpen = false, "Close Cyberdeck");

            // Clickable Quick-Command & Scroll Chips
            int cy = y + 36;
            drawBtn(g, x + 10, cy, 56, 24, "help", CY, () -> exec("help"), "Show full command manual");
            drawBtn(g, x + 70, cy, 62, 24, "ls -a", CY, () -> exec("ls -a"), "List captured & hidden files");
            drawBtn(g, x + 136, cy, 56, 24, "scan", CY, () -> exec("scan"), "Scan nearest room object");
            drawBtn(g, x + 196, cy, 56, 24, "hint", AM, () -> exec("hint"), "Get chapter puzzle hint");
            drawBtn(g, x + 256, cy, 62, 24, "clear", GR, () -> exec("clear"), "Clear terminal scrollback");
            drawBtn(g, x + 324, cy, 86, 24, "▲ PG UP", VI, () -> scrollTerminal(6), "Scroll console up (Mouse Wheel / PgUp)");
            drawBtn(g, x + 414, cy, 94, 24, "▼ PG DN", VI, () -> scrollTerminal(-6), "Scroll console down (Mouse Wheel / PgDn)");
        }

        // Compute wrapped lines & scroll window
        g.setFont(TERM_FONT);
        FontMetrics fm = g.getFontMetrics();
        int textAreaW = wd - 48; // Leave room for scrollbar on right
        List<String> rows = new ArrayList<>();
        for (String s : tl) rows.addAll(wrap(s, fm, textAreaW));

        int topOffset = 72;
        int lineHeight = 20;
        int bodyH = ht - topOffset - 48;
        termMaxRows = Math.max(1, bodyH / lineHeight);
        termTotalRows = rows.size();
        int maxScroll = Math.max(0, termTotalRows - termMaxRows);
        termScroll = Math.max(0, Math.min(maxScroll, termScroll));

        int endIdx = Math.max(0, termTotalRows - termScroll);
        int startIdx = Math.max(0, endIdx - termMaxRows);
        int yy = y + topOffset + 14;

        termBodyRect.setBounds(x + 8, y + topOffset, wd - 16, bodyH);

        for (int i = startIdx; i < endIdx; i++) {
            String raw = rows.get(i);
            Color lineCol = TXT_MAIN;
            Font useFont = TERM_FONT;
            String display = raw;

            if (raw.startsWith("[HDR]")) {
                lineCol = CY; useFont = TERM_BOLD; display = raw.substring(5).trim();
                g.setColor(new Color(0, 248, 255, 28));
                g.fillRect(x + 10, yy - 14, textAreaW + 8, lineHeight - 1);
            } else if (raw.startsWith("[SEC]")) {
                lineCol = AM; useFont = TERM_BOLD; display = raw.substring(5).trim();
            } else if (raw.startsWith("[CMD]")) {
                lineCol = GR; useFont = TERM_FONT; display = raw.substring(5);
            } else if (raw.startsWith("[TIP]")) {
                lineCol = AM; useFont = TERM_FONT; display = raw.substring(5).trim();
            } else if (raw.startsWith("[OK]")) {
                lineCol = GR; useFont = TERM_BOLD; display = raw.substring(4).trim();
            } else if (raw.startsWith("[ERR]")) {
                lineCol = RD; useFont = TERM_BOLD; display = raw.substring(5).trim();
            } else if (raw.startsWith("[IN]")) {
                lineCol = CY; useFont = TERM_BOLD; display = raw.substring(4).trim();
            } else if (raw.startsWith("[OUT]")) {
                lineCol = TXT_MAIN; useFont = TERM_FONT; display = raw.substring(5).trim();
            } else if (raw.startsWith("[SYS]")) {
                lineCol = VI; useFont = TERM_BOLD; display = raw.substring(5).trim();
            }

            g.setFont(useFont);
            drawPixelText(g, display, x + 16, yy, lineCol, Color.BLACK);
            yy += lineHeight;
        }

        // Pixel-Art Interactive Scrollbar Track & Thumb on Right Edge
        int sbX = x + wd - 22, sbY = y + topOffset + 4, sbW = 12, sbH = bodyH - 8;
        pxRect(g, sbX, sbY, sbW, sbH, BLDG_DARK, A(CY, 120), Color.BLACK);
        if (termTotalRows > termMaxRows && termOpen && termAnim > 0.9) {
            int thumbH = Math.max(24, (int) (sbH * (termMaxRows / (double) termTotalRows)));
            double scrollFrac = 1.0 - (termScroll / (double) maxScroll); // 0 at top, 1 at bottom
            int thumbY = sbY + (int) ((sbH - thumbH) * scrollFrac);
            pxRect(g, sbX + 2, thumbY, sbW - 4, thumbH, CY, Color.WHITE, BLDG_BLUE);
            regHit(sbX - 4, sbY, sbW + 8, sbH, () -> {
                double clickFrac = (mouseY - sbY) / (double) sbH;
                termScroll = (int) Math.round((1.0 - Math.max(0, Math.min(1, clickFrac))) * maxScroll);
            }, "Click scrollbar to jump in terminal history");
        } else {
            pxRect(g, sbX + 2, sbY + 2, sbW - 4, sbH - 4, A(CY, 90), null, null);
        }

        // Scrolled-up indicator pill
        if (termScroll > 0 && termOpen && termAnim > 0.9) {
            drawBtn(g, x + wd - 195, y + ht - 68, 165, 22, "▼ JUMP TO LATEST (" + termScroll + ")", AM, () -> termScroll = 0, "Jump back to newest console output");
        }

        // High-contrast command input box at bottom
        int inY = y + ht - 38;
        pxRect(g, x + 10, inY, wd - 82, 28, new Color(16, 26, 56), CY, Color.BLACK);
        g.setFont(TERM_BOLD);
        String promptStr = "> " + tin + ((tick / 25) % 2 == 0 ? "█" : " ");
        drawPixelText(g, promptStr, x + 18, inY + 19, CY, Color.BLACK);

        if (termOpen && termAnim > 0.9) {
            drawBtn(g, x + wd - 66, inY, 56, 28, "RUN", GR, () -> { exec(tin.toString()); tin.setLength(0); tone(600, 22, .18); }, "Execute typed command");
        }
        g.setFont(SMALL); g.setColor(TXT_DIM);
        g.drawString("Mouse Wheel / PgUp-PgDn to scroll | 'help <cmd>' for command manual", x + 12, y + ht + 15);
    }

    // ---------------------------------------------------------------- Clickable Clue Journal [J]
    void drawJournal(Graphics2D g) {
        g.setColor(new Color(10, 12, 34, 242)); g.fillRect(0, 0, W, H);
        g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 20));
        drawPixelText(g, "CONSPIRACY BOARD // CLUE JOURNAL", 30, 40, CY, Color.BLACK);
        g.setFont(SMALL); g.setColor(TXT_DIM);
        g.drawString("Click two clue cards (or ARROWS + ENTER) to connect evidence", 30, 58);
        drawBtn(g, W - 150, 26, 120, 30, "CLOSE [J]", MG, () -> { journal = false; jFirst = -1; }, "Close Conspiracy Board");

        List<Clue> L = clues.found(); int cols = 5, cw = 210, chh = 62, gap = 12, x0 = 26, y0 = 80;
        if (L.isEmpty()) { g.setFont(MONO); g.setColor(TXT_MAIN); g.drawString("No clues logged yet.", 30, 120); return; }
        jSel = Math.min(jSel, L.size() - 1);
        int scrollRow = Math.max(0, jSel / cols - 3);

        g.setStroke(new BasicStroke(2f));
        for (int a = 0; a < L.size(); a++) for (int b = a + 1; b < L.size(); b++) {
            if (!w.f("link." + ClueDB.key(L.get(a).id(), L.get(b).id()))) continue;
            int ra = a / cols - scrollRow, rb = b / cols - scrollRow;
            if (ra < 0 || ra > 3 || rb < 0 || rb > 3) continue;
            g.setColor(A(GR, 220));
            g.drawLine(x0 + (a % cols) * (cw + gap) + cw / 2, y0 + ra * (chh + gap) + chh / 2,
                    x0 + (b % cols) * (cw + gap) + cw / 2, y0 + rb * (chh + gap) + chh / 2);
        }

        for (int i = 0; i < L.size(); i++) {
            final int idx = i;
            int r = i / cols - scrollRow; if (r < 0 || r > 3) continue;
            int x = x0 + (i % cols) * (cw + gap), y = y0 + r * (chh + gap); Clue c = L.get(i);
            Color cc = switch (c.cat()) { case "NPC" -> MG; case "SYMBOL" -> VI; case "FILE" -> GR; case "INSIGHT" -> AM; default -> CY; };
            pxFrame(g, x, y, cw, chh, BLDG_DARK, i == jSel ? Color.WHITE : cc);
            regHit(x, y, cw, chh, () -> journalClickLink(idx), "Click to select/link clue: " + c.title());

            if (i == jFirst) { g.setColor(MG); g.fillRect(x + cw - 16, y + 6, 10, 10); }
            g.setFont(SMALL); g.setColor(cc); g.drawString("[CH." + c.ch() + "] " + c.cat(), x + 8, y + 15);
            g.setFont(MONO); g.setColor(Color.WHITE); FontMetrics fm = g.getFontMetrics();
            List<String> t = wrap(c.title(), fm, cw - 16);
            for (int k = 0; k < Math.min(2, t.size()); k++) g.drawString(t.get(k), x + 8, y + 33 + k * 15);
        }

        Clue s = L.get(jSel); int py0 = 80 + 4 * (chh + gap) + 20;
        box(g, 26, py0, W - 52, H - py0 - 20, CY);
        g.setFont(MONOB); g.setColor(CY); g.drawString(s.title(), 42, py0 + 24);
        g.setFont(MONO); g.setColor(TXT_MAIN);
        int yy = py0 + 48;
        for (String ln : wrap(s.text(), g.getFontMetrics(), W - 90)) { g.drawString(ln, 42, yy); yy += 19; }
        if (jMsgT > 0) { g.setColor(GR); g.drawString(jMsg, 42, H - 34); }
    }

    // ---------------------------------------------------------------- Clickable Menus & Endings
    void drawNetwork(Graphics2D g) {
        int bands = 14;
        for (int b = 0; b < bands; b++) {
            double t = b / (double) (bands - 1);
            g.setColor(t < 0.5 ? mix(SKY_TOP, SKY_MID, t * 2) : mix(SKY_MID, SKY_HORIZON, (t - 0.5) * 2));
            int y0 = (b * H) / bands, y1 = ((b + 1) * H) / bands;
            g.fillRect(0, y0, W, y1 - y0);
        }
        g.setStroke(new BasicStroke(1f));
        for (int i = 0; i < net.length; i++) for (int j = i + 1; j < net.length; j++) {
            double dd = Math.hypot(net[i][0] - net[j][0], net[i][1] - net[j][1]);
            if (dd < 175) {
                g.setColor(A((i + j) % 3 == 0 ? MG : CY, (int) (115 * (1 - dd / 175))));
                g.drawLine(snap(net[i][0]), snap(net[i][1]), snap(net[j][0]), snap(net[j][1]));
            }
        }
        for (int i = 0; i < net.length; i++) {
            int p = snap(4 + 2 * Math.sin(tick / 20.0 + i));
            g.setColor(A(i % 4 == 0 ? AM : CY, 230));
            g.fillRect(snap(net[i][0]) - p / 2, snap(net[i][1]) - p / 2, p, p);
        }
    }

    void drawMenu(Graphics2D g) {
        g.setColor(new Color(10, 12, 34, 115)); g.fillRect(0, 0, W, H);
        g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 74));
        int jit = (tick % 150 < 5) ? snap(rnd.nextInt(9) - 4) : 0;
        g.setColor(A(MG, 200)); g.drawString("MADHACKS", 100 + jit + 4, 160);
        g.setColor(CY); g.drawString("MADHACKS", 100 - jit, 156);
        g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 22)); g.setColor(AM);
        g.drawString("U N D E R G R O U N D   I N T E R N E T", 104, 195);

        if (state == MENU) {
            String[] it = {"Continue", "New Connection", "Load Session", "Settings", "Credits", "Quit"};
            for (int i = 0; i < it.length; i++) {
                final int idx = i;
                boolean dis = i == 0 && newestSlot() < 0;
                int iy = 280 + i * 42;
                g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 22));
                Color c = dis ? new Color(110, 110, 150) : i == msel ? Color.WHITE : CY;
                drawPixelText(g, (i == msel ? "> " : "  ") + it[i] + (i == msel && (tick / 20) % 2 == 0 ? " █" : ""), 110, iy, c, Color.BLACK);
                if (!dis) regHit(105, iy - 24, 340, 34, () -> { msel = idx; activateMenu(idx); }, "Select " + it[i]);
            }
        } else if (state == SETTINGS) {
            g.setFont(MONOB); g.setColor(MG); g.drawString("// SETTINGS (Click to toggle)", 110, 270);
            g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 20));
            String[] n = {"CRT scanlines", "Glitch effects", "Sound"}; boolean[] v = {crt, glitchOn, soundOn};
            for (int i = 0; i < 3; i++) {
                final int idx = i;
                int iy = 320 + i * 40;
                g.setColor(i == ssel ? Color.WHITE : CY);
                g.drawString((i == ssel ? "> " : "  ") + n[i] + ": " + (v[i] ? "ON" : "OFF"), 110, iy);
                regHit(105, iy - 22, 340, 32, () -> {
                    ssel = idx;
                    if (idx == 0) crt = !crt;
                    if (idx == 1) glitchOn = !glitchOn;
                    if (idx == 2) soundOn = !soundOn;
                }, "Toggle " + n[i]);
            }
            drawBtn(g, 110, 455, 140, 32, "BACK [ESC]", MG, () -> state = MENU, "Return to main menu");
        } else if (state == LOAD) {
            g.setFont(MONOB); g.setColor(MG); g.drawString("// LOAD SESSION (Click slot to load)", 110, 270);
            g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 20));
            for (int i = 0; i < 3; i++) {
                final int idx = i;
                int iy = 320 + i * 40;
                File f = saveFile(i);
                String t = f.exists() ? "saved " + new java.util.Date(f.lastModified()) : "(empty)";
                g.setColor(i == ssel ? Color.WHITE : CY);
                g.drawString((i == ssel ? "> " : "  ") + "SLOT " + (i + 1) + "  " + t, 110, iy);
                if (f.exists()) regHit(105, iy - 22, 620, 32, () -> { ssel = idx; if (load(idx)) state = PLAY; }, "Load Slot " + (i + 1));
            }
            drawBtn(g, 110, 455, 140, 32, "BACK [ESC]", MG, () -> state = MENU, "Return to main menu");
        } else if (state == CREDITS) {
            g.setFont(MONOB); g.setColor(MG); g.drawString("// CREDITS", 110, 270);
            g.setFont(MONO); g.setColor(TXT_MAIN);
            String[] c = {
                    "MADHACKS: UNDERGROUND INTERNET",
                    "Scrollable Cyberdeck + Neon Twilight Pixel-Art Edition.",
                    "Built in pure Java Swing."
            };
            for (int i = 0; i < c.length; i++) g.drawString(c[i], 110, 315 + i * 26);
            drawBtn(g, 110, 415, 140, 32, "BACK [ESC]", MG, () -> state = MENU, "Return to main menu");
        }
    }

    void drawEnd(Graphics2D g) {
        g.setColor(new Color(10, 12, 34, 195)); g.fillRect(0, 0, W, H);
        Ending ed = ENDINGS.get(Math.max(0, Math.min(ENDINGS.size() - 1, activeEnding)));
        g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 42));
        drawPixelText(g, ed.title(), 80, 145, ed.accent(), Color.BLACK);
        g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 20));
        g.setColor(Color.WHITE);
        g.drawString("// " + ed.subtitle(), 84, 185);
        g.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 17));
        g.setColor(TXT_MAIN);
        int y = 245;
        for (String ln : wrap(ed.narrative(), g.getFontMetrics(), 960)) {
            g.drawString(ln, 84, y);
            y += 28;
        }
        g.setFont(MONO); g.setColor(CY);
        g.drawString("Clues Collected: " + clues.found().size() + " / " + clues.defs.size() + "   |   Ending " + (activeEnding + 1) + " of 5", 84, y + 40);
        drawBtn(g, 84, H - 70, 220, 36, "MAIN MENU [ENTER]", CY, () -> state = MENU, "Return to Main Menu");
    }

    public static void main(String[] a) {
        SwingUtilities.invokeLater(() -> {
            JFrame f = new JFrame("MADHACKS: UNDERGROUND INTERNET");
            MadHacks p = new MadHacks();
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            f.setContentPane(p);
            f.setResizable(false);
            f.pack();
            f.setLocationRelativeTo(null);
            f.setVisible(true);
            p.requestFocusInWindow();
        });
    }
}
