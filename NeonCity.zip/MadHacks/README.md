# MADHACKS: UNDERGROUND INTERNET (Scrollable Cyberdeck + Neon Twilight Pixel-Art Edition)

## What's New
1. **Scrollable Cyberdeck Command Line (`[TAB]`)**:
   - **Mouse Wheel Scrolling**: Scroll up and down anywhere inside the terminal history using your mouse wheel.
   - **Keyboard Scrolling**: Press `Page Up` / `Page Down` (or `Shift + Up` / `Shift + Down`) to scroll through long manuals like `help`.
   - **Clickable Scrollbar & Buttons**: Click the `▲ PG UP` / `▼ PG DN` buttons, click directly along the right-edge pixel scrollbar track, or click `▼ JUMP TO LATEST` to snap back to the newest output.

2. **Neon Twilight Cyberpunk Pixel-Art Atmosphere**:
   - **Vibrant Twilight Skyline**: Dithered deep-indigo to violet and hot-magenta horizon sky with a glowing pixel moon, twinkling stars, and a clock tower (`03:12`).
   - **Cobalt-Blue & Violet City Towers**: Pixel-art skyscrapers with rooftop AC units, diagonal-glint violet windows, elevated monorail tracks, and vertical neon signs (`RANGO`, `VACANCY`, `NET-01`, `1969`).
   - **Street-Level Neon Storefronts**: Mint-green and hot-pink neon roof trims, retro coral-red vending machines, and luminous floating pixel motes.

## Build & Run
```bash
javac MadHacks.java
java MadHacks
```
